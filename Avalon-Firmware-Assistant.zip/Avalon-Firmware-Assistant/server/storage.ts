import { db } from "./db";
import {
  miners, profiles, buildJobs, sites, areas, racks, shelves, minerModels,
  type Miner, type InsertMiner, type UpdateMinerRequest,
  type Profile, type InsertProfile, type UpdateProfileRequest,
  type BuildJob, type InsertBuildJob,
  type Site, type InsertSite,
  type Area, type InsertArea,
  type Rack, type InsertRack,
  type Shelf, type InsertShelf,
  type MinerModel, type InsertMinerModel,
} from "@shared/schema";
import { eq, sql, inArray } from "drizzle-orm";

export interface IStorage {
  // Miner Models
  getMinerModels(): Promise<MinerModel[]>;
  getMinerModel(id: number): Promise<MinerModel | undefined>;
  createMinerModel(model: InsertMinerModel): Promise<MinerModel>;

  // Sites
  getSites(): Promise<Site[]>;
  getSite(id: number): Promise<Site | undefined>;
  createSite(site: InsertSite): Promise<Site>;
  updateSite(id: number, updates: Partial<InsertSite>): Promise<Site>;
  deleteSite(id: number): Promise<void>;

  // Areas
  getAreasBySite(siteId: number): Promise<Area[]>;
  createArea(area: InsertArea): Promise<Area>;
  updateArea(id: number, updates: Partial<InsertArea>): Promise<Area>;
  deleteArea(id: number): Promise<void>;

  // Racks
  getRacksByArea(areaId: number): Promise<Rack[]>;
  createRack(rack: InsertRack): Promise<Rack>;
  updateRack(id: number, updates: Partial<InsertRack>): Promise<Rack>;
  deleteRack(id: number): Promise<void>;

  // Shelves
  getShelvesByRack(rackId: number): Promise<Shelf[]>;
  createShelf(shelf: InsertShelf): Promise<Shelf>;
  updateShelf(id: number, updates: Partial<InsertShelf>): Promise<Shelf>;
  deleteShelf(id: number): Promise<void>;

  // Miners
  getMiners(): Promise<Miner[]>;
  getMiner(id: number): Promise<Miner | undefined>;
  getMinersByShelf(shelfId: number): Promise<Miner[]>;
  getMinerIpsByShelfIds(shelfIds: number[]): Promise<string[]>;
  createMiner(miner: InsertMiner): Promise<Miner>;
  updateMiner(id: number, updates: UpdateMinerRequest): Promise<Miner>;
  deleteMiner(id: number): Promise<void>;

  // Hierarchy counts
  getMinerCountBySite(siteId: number): Promise<number>;
  getMinerCountByArea(areaId: number): Promise<number>;
  getMinerCountByRack(rackId: number): Promise<number>;
  getMinerCountByShelf(shelfId: number): Promise<number>;

  // Profiles
  getProfiles(): Promise<Profile[]>;
  getProfile(id: number): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(id: number, updates: UpdateProfileRequest): Promise<Profile>;
  deleteProfile(id: number): Promise<void>;

  // Build Jobs
  getBuildJobs(): Promise<BuildJob[]>;
  createBuildJob(job: InsertBuildJob): Promise<BuildJob>;
}

export class DatabaseStorage implements IStorage {
  // Miner Models
  async getMinerModels(): Promise<MinerModel[]> {
    return await db.select().from(minerModels);
  }

  async getMinerModel(id: number): Promise<MinerModel | undefined> {
    const [model] = await db.select().from(minerModels).where(eq(minerModels.id, id));
    return model;
  }

  async createMinerModel(insertModel: InsertMinerModel): Promise<MinerModel> {
    const [model] = await db.insert(minerModels).values(insertModel).returning();
    return model;
  }

  // Sites
  async getSites(): Promise<Site[]> {
    return await db.select().from(sites);
  }

  async getSite(id: number): Promise<Site | undefined> {
    const [site] = await db.select().from(sites).where(eq(sites.id, id));
    return site;
  }

  async createSite(insertSite: InsertSite): Promise<Site> {
    const [site] = await db.insert(sites).values(insertSite).returning();
    return site;
  }

  async updateSite(id: number, updates: Partial<InsertSite>): Promise<Site> {
    const [updated] = await db.update(sites).set(updates).where(eq(sites.id, id)).returning();
    return updated;
  }

  async deleteSite(id: number): Promise<void> {
    await db.delete(sites).where(eq(sites.id, id));
  }

  // Areas
  async getAreasBySite(siteId: number): Promise<Area[]> {
    return await db.select().from(areas).where(eq(areas.siteId, siteId));
  }

  async createArea(insertArea: InsertArea): Promise<Area> {
    const [area] = await db.insert(areas).values(insertArea).returning();
    return area;
  }

  async updateArea(id: number, updates: Partial<InsertArea>): Promise<Area> {
    const [updated] = await db.update(areas).set(updates).where(eq(areas.id, id)).returning();
    return updated;
  }

  async deleteArea(id: number): Promise<void> {
    await db.delete(areas).where(eq(areas.id, id));
  }

  // Racks
  async getRacksByArea(areaId: number): Promise<Rack[]> {
    return await db.select().from(racks).where(eq(racks.areaId, areaId));
  }

  async createRack(insertRack: InsertRack): Promise<Rack> {
    const [rack] = await db.insert(racks).values(insertRack).returning();
    return rack;
  }

  async updateRack(id: number, updates: Partial<InsertRack>): Promise<Rack> {
    const [updated] = await db.update(racks).set(updates).where(eq(racks.id, id)).returning();
    return updated;
  }

  async deleteRack(id: number): Promise<void> {
    await db.delete(racks).where(eq(racks.id, id));
  }

  // Shelves
  async getShelvesByRack(rackId: number): Promise<Shelf[]> {
    return await db.select().from(shelves).where(eq(shelves.rackId, rackId));
  }

  async createShelf(insertShelf: InsertShelf): Promise<Shelf> {
    const [shelf] = await db.insert(shelves).values(insertShelf).returning();
    return shelf;
  }

  async updateShelf(id: number, updates: Partial<InsertShelf>): Promise<Shelf> {
    const [updated] = await db.update(shelves).set(updates).where(eq(shelves.id, id)).returning();
    return updated;
  }

  async deleteShelf(id: number): Promise<void> {
    await db.delete(shelves).where(eq(shelves.id, id));
  }

  // Miners
  async getMiners(): Promise<Miner[]> {
    return await db.select().from(miners);
  }

  async getMiner(id: number): Promise<Miner | undefined> {
    const [miner] = await db.select().from(miners).where(eq(miners.id, id));
    return miner;
  }

  async getMinersByShelf(shelfId: number): Promise<Miner[]> {
    return await db.select().from(miners).where(eq(miners.shelfId, shelfId));
  }

  async getMinerIpsByShelfIds(shelfIds: number[]): Promise<string[]> {
    if (shelfIds.length === 0) return [];
    const result = await db.select({ ipAddress: miners.ipAddress })
      .from(miners)
      .where(inArray(miners.shelfId, shelfIds));
    return result.map(r => r.ipAddress);
  }

  async createMiner(insertMiner: InsertMiner): Promise<Miner> {
    const [miner] = await db.insert(miners).values(insertMiner).returning();
    return miner;
  }

  async updateMiner(id: number, updates: UpdateMinerRequest): Promise<Miner> {
    const [updated] = await db.update(miners).set(updates).where(eq(miners.id, id)).returning();
    return updated;
  }

  async deleteMiner(id: number): Promise<void> {
    await db.delete(miners).where(eq(miners.id, id));
  }

  // Hierarchy counts
  async getMinerCountBySite(siteId: number): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)::int` })
      .from(miners)
      .innerJoin(shelves, eq(miners.shelfId, shelves.id))
      .innerJoin(racks, eq(shelves.rackId, racks.id))
      .innerJoin(areas, eq(racks.areaId, areas.id))
      .where(eq(areas.siteId, siteId));
    return result[0]?.count ?? 0;
  }

  async getMinerCountByArea(areaId: number): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)::int` })
      .from(miners)
      .innerJoin(shelves, eq(miners.shelfId, shelves.id))
      .innerJoin(racks, eq(shelves.rackId, racks.id))
      .where(eq(racks.areaId, areaId));
    return result[0]?.count ?? 0;
  }

  async getMinerCountByRack(rackId: number): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)::int` })
      .from(miners)
      .innerJoin(shelves, eq(miners.shelfId, shelves.id))
      .where(eq(shelves.rackId, rackId));
    return result[0]?.count ?? 0;
  }

  async getMinerCountByShelf(shelfId: number): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)::int` })
      .from(miners)
      .where(eq(miners.shelfId, shelfId));
    return result[0]?.count ?? 0;
  }

  // Profiles
  async getProfiles(): Promise<Profile[]> {
    return await db.select().from(profiles);
  }

  async getProfile(id: number): Promise<Profile | undefined> {
    const [profile] = await db.select().from(profiles).where(eq(profiles.id, id));
    return profile;
  }

  async createProfile(insertProfile: InsertProfile): Promise<Profile> {
    const [profile] = await db.insert(profiles).values(insertProfile).returning();
    return profile;
  }

  async updateProfile(id: number, updates: UpdateProfileRequest): Promise<Profile> {
    const [updated] = await db.update(profiles).set(updates).where(eq(profiles.id, id)).returning();
    return updated;
  }

  async deleteProfile(id: number): Promise<void> {
    await db.delete(profiles).where(eq(profiles.id, id));
  }

  // Build Jobs
  async getBuildJobs(): Promise<BuildJob[]> {
    return await db.select().from(buildJobs);
  }

  async createBuildJob(insertJob: InsertBuildJob): Promise<BuildJob> {
    const [job] = await db.insert(buildJobs).values(insertJob).returning();
    return job;
  }
}

export const storage = new DatabaseStorage();
