import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // === Miner Models ===
  app.get(api.minerModels.list.path, async (req, res) => {
    const models = await storage.getMinerModels();
    res.json(models);
  });

  app.get(api.minerModels.get.path, async (req, res) => {
    const model = await storage.getMinerModel(Number(req.params.id));
    if (!model) return res.status(404).json({ message: "Model not found" });
    res.json(model);
  });

  // === Miners ===
  app.get(api.miners.list.path, async (req, res) => {
    const miners = await storage.getMiners();
    res.json(miners);
  });

  app.get(api.miners.get.path, async (req, res) => {
    const miner = await storage.getMiner(Number(req.params.id));
    if (!miner) return res.status(404).json({ message: "Miner not found" });
    res.json(miner);
  });

  app.post(api.miners.create.path, async (req, res) => {
    try {
      const input = api.miners.create.input.parse(req.body);
      const miner = await storage.createMiner(input);
      res.status(201).json(miner);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.miners.update.path, async (req, res) => {
    try {
      const input = api.miners.update.input.parse(req.body);
      const miner = await storage.updateMiner(Number(req.params.id), input);
      if (!miner) return res.status(404).json({ message: "Miner not found" });
      res.json(miner);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.delete(api.miners.delete.path, async (req, res) => {
    await storage.deleteMiner(Number(req.params.id));
    res.status(204).send();
  });

  // === Profiles ===
  app.get(api.profiles.list.path, async (req, res) => {
    const profiles = await storage.getProfiles();
    res.json(profiles);
  });

  app.get(api.profiles.get.path, async (req, res) => {
    const profile = await storage.getProfile(Number(req.params.id));
    if (!profile) return res.status(404).json({ message: "Profile not found" });
    res.json(profile);
  });

  app.post(api.profiles.create.path, async (req, res) => {
    try {
      const input = api.profiles.create.input.parse(req.body);
      const profile = await storage.createProfile(input);
      res.status(201).json(profile);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.profiles.update.path, async (req, res) => {
    try {
      const input = api.profiles.update.input.parse(req.body);
      const profile = await storage.updateProfile(Number(req.params.id), input);
      if (!profile) return res.status(404).json({ message: "Profile not found" });
      res.json(profile);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.delete(api.profiles.delete.path, async (req, res) => {
    await storage.deleteProfile(Number(req.params.id));
    res.status(204).send();
  });

  // === AI Optimization ===
  app.post(api.ai.optimize.path, async (req, res) => {
    try {
      const { goal, constraints } = api.ai.optimize.input.parse(req.body);

      const prompt = `
        You are an expert firmware engineer for Avalon A16 ASIC miners.
        Suggest optimal tuning parameters based on the following goal: ${goal}.
        
        Constraints:
        ${constraints?.maxPower ? `- Max Power: ${constraints.maxPower}W` : ""}
        ${constraints?.minHashrate ? `- Min Hashrate: ${constraints.minHashrate}TH/s` : ""}
        ${constraints?.maxTemp ? `- Max Temp: ${constraints.maxTemp}°C` : ""}

        Avalon A16 specs:
        - Nominal Hashrate: ~100-110 TH/s
        - Nominal Power: ~3200W
        - Voltage Offset Range: -2 to +1
        - Fan Speed: 0-100%
        - Chip Frequency Range: 200-400 MHz (default 250 MHz)
        - Thermal Threshold Range: 10-100°C (default 85°C)
        - Power Range: 3.00-4.00 kW (3000-4000W)
        
        Power vs Heat curve reference (MHz -> Power -> Chip Temp):
        200MHz -> 3000W -> 55°C
        225MHz -> 3100W -> 62°C
        250MHz -> 3200W -> 68°C (default)
        275MHz -> 3400W -> 78°C
        300MHz -> 3700W -> 90°C
        400MHz -> 4000W -> 100°C (max overclock)

        Return a JSON object with:
        - voltageOffset (integer, range -2 to +1)
        - fanSpeed (integer percentage, 0-100)
        - mhzFrequency (integer, chip frequency in MHz, range 200-400)
        - thermalThreshold (integer, thermal cutoff in Celsius, range 10-100)
        - targetHashrate (estimated integer in TH/s)
        - targetPower (estimated integer in Watts, range 3000-4000)
        - reasoning (short explanation string including MHz recommendation rationale)
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-5.1", // Using the model recommended in the blueprint
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      
      res.json({
        recommendedProfile: {
          voltageOffset: result.voltageOffset || 0,
          fanSpeed: result.fanSpeed || 80,
          mhzFrequency: Math.min(Math.max(result.mhzFrequency || 250, 200), 400),
          thermalThreshold: Math.min(Math.max(result.thermalThreshold || 85, 10), 100),
          targetHashrate: result.targetHashrate,
          targetPower: Math.min(Math.max(result.targetPower || 3200, 3000), 4000),
          isAiOptimized: true,
        },
        reasoning: result.reasoning || "AI generated optimization based on standard A16 parameters.",
      });

    } catch (err) {
      console.error("AI Optimization Error:", err);
      res.status(500).json({ message: "Failed to generate AI optimization" });
    }
  });

  // === Firmware Config Export ===
  app.get("/api/profiles/:id/export", async (req, res) => {
    const profile = await storage.getProfile(Number(req.params.id));
    if (!profile) return res.status(404).json({ message: "Profile not found" });

    const format = (req.query.format as string) || "json";

    const configData = {
      _header: {
        generator: "Avalon by Hut8 Firmware Config Tool",
        version: "2.4.0",
        model: "Avalon A16 (Canaan AvalonMiner 1266)",
        exportedAt: new Date().toISOString(),
        profileName: profile.name,
      },
      bmminer: {
        "api-listen": true,
        "api-network": false,
        "api-allow": "W:127.0.0.1",
        "avalon10-freq": profile.mhzFrequency || 250,
        "avalon10-voltage-level": profile.voltageOffset || 0,
        "avalon10-fan-pct": profile.fanSpeed || 100,
        "avalon10-target-temp": profile.thermalThreshold || 85,
        "avalon10-target-freq": profile.mhzFrequency || 250,
        "avalon10-thermal-cutoff": profile.thermalThreshold || 85,
      },
      cgminer: {
        "no-pool-disable": true,
        "no-submit-stale": false,
        "api-description": `AvalonByHut8|${profile.name}`,
        "queue": 9999,
        "scan-time": 10,
        "expiry": 120,
        "log": 5,
      },
      tuning: {
        targetHashrateTHs: profile.targetHashrate,
        targetPowerW: profile.targetPower,
        chipFrequencyMHz: profile.mhzFrequency || 250,
        voltageOffsetLevel: profile.voltageOffset || 0,
        fanSpeedPercent: profile.fanSpeed || 100,
        thermalThresholdC: profile.thermalThreshold || 85,
        powerCapEnabled: profile.powerCapEnabled || false,
        powerCapLimitW: profile.powerCapLimit || 3500,
        aiOptimized: profile.isAiOptimized || false,
      },
    };

    if (format === "conf") {
      const lines = [
        `# Avalon by Hut8 Firmware Configuration`,
        `# Profile: ${profile.name}`,
        `# Exported: ${new Date().toISOString()}`,
        `# Model: Avalon A16 (Canaan AvalonMiner 1266)`,
        ``,
        `[bmminer]`,
        ...Object.entries(configData.bmminer).map(([k, v]) => `${k} = ${v}`),
        ``,
        `[cgminer]`,
        ...Object.entries(configData.cgminer).map(([k, v]) => `${k} = ${v}`),
        ``,
        `[tuning]`,
        ...Object.entries(configData.tuning).map(([k, v]) => `${k} = ${v}`),
      ];
      const content = lines.join("\n");
      res.setHeader("Content-Type", "text/plain");
      res.setHeader("Content-Disposition", `attachment; filename="${profile.name.replace(/\s+/g, '_')}_config.conf"`);
      return res.send(content);
    }

    res.setHeader("Content-Type", "application/json");
    res.setHeader("Content-Disposition", `attachment; filename="${profile.name.replace(/\s+/g, '_')}_config.json"`);
    res.json(configData);
  });

  // === Build Jobs ===
  app.post(api.builds.create.path, async (req, res) => {
     try {
      const input = api.builds.create.input.parse(req.body);
      const job = await storage.createBuildJob(input);
      
      // Simulate build process (in a real app this would be a background queue)
      setTimeout(async () => {
         // This is a simulation since we can't actually compile firmware here
         console.log(`[BuildJob ${job.id}] Starting build for Profile ${job.profileId}...`);
      }, 1000);

      res.status(201).json(job);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.get(api.builds.list.path, async (req, res) => {
    const jobs = await storage.getBuildJobs();
    res.json(jobs);
  });

  // === Sites ===
  app.get("/api/sites", async (req, res) => {
    const allSites = await storage.getSites();
    res.json(allSites);
  });

  app.post("/api/sites", async (req, res) => {
    try {
      const input = api.sites.create.input.parse(req.body);
      const site = await storage.createSite(input);
      res.status(201).json(site);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  app.put("/api/sites/:id", async (req, res) => {
    try {
      const input = api.sites.update.input.parse(req.body);
      const site = await storage.updateSite(Number(req.params.id), input);
      res.json(site);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  app.delete("/api/sites/:id", async (req, res) => {
    await storage.deleteSite(Number(req.params.id));
    res.status(204).end();
  });

  // === Areas ===
  app.get("/api/sites/:siteId/areas", async (req, res) => {
    const areaList = await storage.getAreasBySite(Number(req.params.siteId));
    res.json(areaList);
  });

  app.post("/api/areas", async (req, res) => {
    try {
      const input = api.areas.create.input.parse(req.body);
      const area = await storage.createArea(input);
      res.status(201).json(area);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  app.put("/api/areas/:id", async (req, res) => {
    try {
      const input = api.areas.update.input.parse(req.body);
      const area = await storage.updateArea(Number(req.params.id), input);
      res.json(area);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  app.delete("/api/areas/:id", async (req, res) => {
    await storage.deleteArea(Number(req.params.id));
    res.status(204).end();
  });

  // === Racks ===
  app.get("/api/areas/:areaId/racks", async (req, res) => {
    const rackList = await storage.getRacksByArea(Number(req.params.areaId));
    res.json(rackList);
  });

  app.post("/api/racks", async (req, res) => {
    try {
      const input = api.racks.create.input.parse(req.body);
      const rack = await storage.createRack(input);
      res.status(201).json(rack);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  app.put("/api/racks/:id", async (req, res) => {
    try {
      const input = api.racks.update.input.parse(req.body);
      const rack = await storage.updateRack(Number(req.params.id), input);
      res.json(rack);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  app.delete("/api/racks/:id", async (req, res) => {
    await storage.deleteRack(Number(req.params.id));
    res.status(204).end();
  });

  // === Shelves ===
  app.get("/api/racks/:rackId/shelves", async (req, res) => {
    const shelfList = await storage.getShelvesByRack(Number(req.params.rackId));
    res.json(shelfList);
  });

  app.post("/api/shelves", async (req, res) => {
    try {
      const input = api.shelves.create.input.parse(req.body);
      const shelf = await storage.createShelf(input);
      res.status(201).json(shelf);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  app.put("/api/shelves/:id", async (req, res) => {
    try {
      const input = api.shelves.update.input.parse(req.body);
      const shelf = await storage.updateShelf(Number(req.params.id), input);
      res.json(shelf);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  app.delete("/api/shelves/:id", async (req, res) => {
    await storage.deleteShelf(Number(req.params.id));
    res.status(204).end();
  });

  // === Shelves -> Miners ===
  app.get("/api/shelves/:shelfId/miners", async (req, res) => {
    const minerList = await storage.getMinersByShelf(Number(req.params.shelfId));
    res.json(minerList);
  });

  // === Hierarchy Tree (with counts) ===
  app.get("/api/hierarchy/tree", async (req, res) => {
    try {
      const allSites = await storage.getSites();
      const tree = await Promise.all(allSites.map(async (site) => {
        const siteAreas = await storage.getAreasBySite(site.id);
        const areasWithChildren = await Promise.all(siteAreas.map(async (area) => {
          const areaRacks = await storage.getRacksByArea(area.id);
          const racksWithChildren = await Promise.all(areaRacks.map(async (rack) => {
            const rackShelves = await storage.getShelvesByRack(rack.id);
            const shelvesWithCounts = await Promise.all(rackShelves.map(async (shelf) => {
              const count = await storage.getMinerCountByShelf(shelf.id);
              return { ...shelf, minerCount: count };
            }));
            const rackMinerCount = shelvesWithCounts.reduce((sum, s) => sum + s.minerCount, 0);
            return { ...rack, shelves: shelvesWithCounts, minerCount: rackMinerCount };
          }));
          const areaMinerCount = racksWithChildren.reduce((sum, r) => sum + r.minerCount, 0);
          return { ...area, racks: racksWithChildren, minerCount: areaMinerCount };
        }));
        const siteMinerCount = areasWithChildren.reduce((sum, a) => sum + a.minerCount, 0);
        return { ...site, areas: areasWithChildren, minerCount: siteMinerCount };
      }));
      res.json(tree);
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  // === Fleet Deploy ===
  app.post("/api/fleet/deploy", async (req, res) => {
    try {
      const { profileId, minerIps, siteIds, areaIds, rackIds, shelfIds } = req.body;
      if (!profileId) {
        return res.status(400).json({ message: "profileId required" });
      }

      const profile = await storage.getProfile(profileId);
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }

      let allIps: string[] = minerIps || [];

      if (shelfIds && Array.isArray(shelfIds) && shelfIds.length > 0) {
        const ips = await storage.getMinerIpsByShelfIds(shelfIds);
        allIps = [...allIps, ...ips];
      }
      if (rackIds && Array.isArray(rackIds) && rackIds.length > 0) {
        for (const rackId of rackIds) {
          const rackShelves = await storage.getShelvesByRack(rackId);
          if (rackShelves.length > 0) {
            const ips = await storage.getMinerIpsByShelfIds(rackShelves.map(s => s.id));
            allIps = [...allIps, ...ips];
          }
        }
      }
      if (areaIds && Array.isArray(areaIds) && areaIds.length > 0) {
        for (const areaId of areaIds) {
          const areaRacks = await storage.getRacksByArea(areaId);
          for (const rack of areaRacks) {
            const rackShelves = await storage.getShelvesByRack(rack.id);
            if (rackShelves.length > 0) {
              const ips = await storage.getMinerIpsByShelfIds(rackShelves.map(s => s.id));
              allIps = [...allIps, ...ips];
            }
          }
        }
      }
      if (siteIds && Array.isArray(siteIds) && siteIds.length > 0) {
        for (const siteId of siteIds) {
          const siteAreas = await storage.getAreasBySite(siteId);
          for (const area of siteAreas) {
            const areaRacks = await storage.getRacksByArea(area.id);
            for (const rack of areaRacks) {
              const rackShelves = await storage.getShelvesByRack(rack.id);
              if (rackShelves.length > 0) {
                const ips = await storage.getMinerIpsByShelfIds(rackShelves.map(s => s.id));
                allIps = [...allIps, ...ips];
              }
            }
          }
        }
      }

      allIps = Array.from(new Set(allIps));

      if (allIps.length === 0) {
        return res.status(400).json({ message: "No miner IPs resolved from selection" });
      }

      const configPayload = {
        "avalon10-freq": profile.mhzFrequency || 250,
        "avalon10-voltage-level": profile.voltageOffset || 0,
        "avalon10-fan-pct": profile.fanSpeed || 100,
        "avalon10-target-temp": profile.thermalThreshold || 85,
        "avalon10-thermal-cutoff": profile.thermalThreshold || 85,
      };

      const BATCH_SIZE = 50;
      const results: Array<{ ip: string; success: boolean; message: string }> = [];
      for (let i = 0; i < allIps.length; i += BATCH_SIZE) {
        const batch = allIps.slice(i, i + BATCH_SIZE);
        const batchResults = await Promise.all(
          batch.map(async (ip: string) => {
            try {
              const controller = new AbortController();
              const timeout = setTimeout(() => controller.abort(), 5000);

              const response = await fetch(`http://${ip}:4028/api`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ command: "ascset", parameter: JSON.stringify(configPayload) }),
                signal: controller.signal,
              });
              clearTimeout(timeout);

              if (response.ok) {
                return { ip, success: true, message: "Config deployed successfully" };
              } else {
                return { ip, success: false, message: `HTTP ${response.status}: ${response.statusText}` };
              }
            } catch (err: any) {
              if (err.name === "AbortError") {
                return { ip, success: false, message: "Connection timed out (5s)" };
              }
              return { ip, success: false, message: err.message || "Connection failed" };
            }
          })
        );
        results.push(...batchResults);
      }

      res.json({ profileId, profileName: profile.name, totalMiners: allIps.length, results });
    } catch (error) {
      res.status(500).json({ message: (error as Error).message });
    }
  });

  return httpServer;
}

async function seedDatabase() {
  const existingModels = await storage.getMinerModels();
  if (existingModels.length === 0) {
    const modelData: Array<Parameters<typeof storage.createMinerModel>[0]> = [
      // Air-Cooled Industrial
      { name: "A16XP-300T", series: "A16", coolingType: "air", defaultHashrate: 300, defaultPower: 3850, efficiency: "12.8", minFrequency: 200, maxFrequency: 500, defaultFrequency: 350, minPower: 3000, maxPower: 4500, minThermal: 10, maxThermal: 100, defaultThermal: 80, minVoltageOffset: -2, maxVoltageOffset: 2, hasFans: true },
      { name: "A16-282T", series: "A16", coolingType: "air", defaultHashrate: 282, defaultPower: 3900, efficiency: "13.8", minFrequency: 200, maxFrequency: 480, defaultFrequency: 340, minPower: 3000, maxPower: 4500, minThermal: 10, maxThermal: 100, defaultThermal: 80, minVoltageOffset: -2, maxVoltageOffset: 2, hasFans: true },
      { name: "A15 Pro (A1566)", series: "A15", coolingType: "air", defaultHashrate: 218, defaultPower: 3660, efficiency: "16.8", minFrequency: 200, maxFrequency: 400, defaultFrequency: 300, minPower: 2800, maxPower: 4200, minThermal: 10, maxThermal: 100, defaultThermal: 85, minVoltageOffset: -2, maxVoltageOffset: 1, hasFans: true },
      { name: "A15-200T", series: "A15", coolingType: "air", defaultHashrate: 200, defaultPower: 3760, efficiency: "18.8", minFrequency: 200, maxFrequency: 400, defaultFrequency: 280, minPower: 2800, maxPower: 4200, minThermal: 10, maxThermal: 100, defaultThermal: 85, minVoltageOffset: -2, maxVoltageOffset: 1, hasFans: true },
      { name: "A15SE-176T", series: "A15", coolingType: "air", defaultHashrate: 176, defaultPower: 3562, efficiency: "19.9", minFrequency: 200, maxFrequency: 380, defaultFrequency: 260, minPower: 2600, maxPower: 4000, minThermal: 10, maxThermal: 100, defaultThermal: 85, minVoltageOffset: -2, maxVoltageOffset: 1, hasFans: true },
      { name: "A1566 (A15 Base)", series: "A15", coolingType: "air", defaultHashrate: 188, defaultPower: 3420, efficiency: "18.5", minFrequency: 200, maxFrequency: 400, defaultFrequency: 270, minPower: 2600, maxPower: 4000, minThermal: 10, maxThermal: 100, defaultThermal: 85, minVoltageOffset: -2, maxVoltageOffset: 1, hasFans: true },
      // Hydro-Cooled
      { name: "A1566HA-480T", series: "A15 Hydro", coolingType: "hydro", defaultHashrate: 480, defaultPower: 8064, efficiency: "16.8", minFrequency: 200, maxFrequency: 450, defaultFrequency: 350, minPower: 6000, maxPower: 9500, minThermal: 10, maxThermal: 80, defaultThermal: 55, minVoltageOffset: -2, maxVoltageOffset: 2, hasFans: false },
      { name: "A1566HA-460T", series: "A15 Hydro", coolingType: "hydro", defaultHashrate: 460, defaultPower: 8200, efficiency: "17.8", minFrequency: 200, maxFrequency: 440, defaultFrequency: 340, minPower: 6000, maxPower: 9500, minThermal: 10, maxThermal: 80, defaultThermal: 55, minVoltageOffset: -2, maxVoltageOffset: 2, hasFans: false },
      { name: "A1566HA-440T", series: "A15 Hydro", coolingType: "hydro", defaultHashrate: 440, defaultPower: 7400, efficiency: "16.8", minFrequency: 200, maxFrequency: 430, defaultFrequency: 330, minPower: 5500, maxPower: 9000, minThermal: 10, maxThermal: 80, defaultThermal: 55, minVoltageOffset: -2, maxVoltageOffset: 2, hasFans: false },
      { name: "A15eHA-400T", series: "A15 Hydro", coolingType: "hydro", defaultHashrate: 400, defaultPower: 6720, efficiency: "16.8", minFrequency: 200, maxFrequency: 420, defaultFrequency: 320, minPower: 5000, maxPower: 8000, minThermal: 10, maxThermal: 80, defaultThermal: 55, minVoltageOffset: -2, maxVoltageOffset: 2, hasFans: false },
      // Immersion-Cooled
      { name: "A1366I-125T", series: "A13 Immersion", coolingType: "immersion", defaultHashrate: 125, defaultPower: 3570, efficiency: "30.0", minFrequency: 150, maxFrequency: 350, defaultFrequency: 250, minPower: 2500, maxPower: 4200, minThermal: 20, maxThermal: 80, defaultThermal: 50, minVoltageOffset: -2, maxVoltageOffset: 1, hasFans: false },
      { name: "A1366I-119T", series: "A13 Immersion", coolingType: "immersion", defaultHashrate: 119, defaultPower: 3570, efficiency: "30.0", minFrequency: 150, maxFrequency: 350, defaultFrequency: 240, minPower: 2500, maxPower: 4200, minThermal: 20, maxThermal: 80, defaultThermal: 50, minVoltageOffset: -2, maxVoltageOffset: 1, hasFans: false },
      // Home / Prosumer
      { name: "Avalon Q", series: "Home", coolingType: "air", defaultHashrate: 90, defaultPower: 1674, efficiency: "18.6", minFrequency: 100, maxFrequency: 300, defaultFrequency: 200, minPower: 800, maxPower: 2000, minThermal: 10, maxThermal: 85, defaultThermal: 70, minVoltageOffset: -2, maxVoltageOffset: 1, hasFans: true },
      { name: "Avalon Mini 3", series: "Home", coolingType: "air", defaultHashrate: 37, defaultPower: 800, efficiency: "21.3", minFrequency: 80, maxFrequency: 250, defaultFrequency: 160, minPower: 500, maxPower: 1200, minThermal: 10, maxThermal: 85, defaultThermal: 65, minVoltageOffset: -2, maxVoltageOffset: 1, hasFans: true },
      { name: "Avalon Nano 3S", series: "Home", coolingType: "air", defaultHashrate: 6, defaultPower: 140, efficiency: "23.3", minFrequency: 50, maxFrequency: 200, defaultFrequency: 120, minPower: 100, maxPower: 250, minThermal: 10, maxThermal: 75, defaultThermal: 60, minVoltageOffset: -1, maxVoltageOffset: 1, hasFans: true },
    ];
    for (const model of modelData) {
      await storage.createMinerModel(model);
    }
  }

  const existingSites = await storage.getSites();
  if (existingSites.length === 0) {
    const site1 = await storage.createSite({ name: "Drumheller Facility", location: "Alberta, Canada" });
    const site2 = await storage.createSite({ name: "Medicine Hat DC", location: "Alberta, Canada" });

    const area1 = await storage.createArea({ name: "Hall A", siteId: site1.id });
    const area2 = await storage.createArea({ name: "Hall B", siteId: site1.id });
    const area3 = await storage.createArea({ name: "Container Yard", siteId: site2.id });

    const rack1 = await storage.createRack({ name: "Rack A-01", areaId: area1.id });
    const rack2 = await storage.createRack({ name: "Rack A-02", areaId: area1.id });
    const rack3 = await storage.createRack({ name: "Rack B-01", areaId: area2.id });
    const rack4 = await storage.createRack({ name: "Rack C-01", areaId: area3.id });

    const shelf1 = await storage.createShelf({ name: "Shelf 1", rackId: rack1.id });
    const shelf2 = await storage.createShelf({ name: "Shelf 2", rackId: rack1.id });
    const shelf3 = await storage.createShelf({ name: "Shelf 1", rackId: rack2.id });
    const shelf4 = await storage.createShelf({ name: "Shelf 1", rackId: rack3.id });
    const shelf5 = await storage.createShelf({ name: "Shelf 1", rackId: rack4.id });
    const shelf6 = await storage.createShelf({ name: "Shelf 2", rackId: rack4.id });

    let ipCounter = 1;
    const createMinersForShelf = async (shelfId: number, count: number, subnet: string) => {
      for (let i = 0; i < count; i++) {
        const octet3 = Math.floor(ipCounter / 254);
        const octet4 = (ipCounter % 254) + 1;
        await storage.createMiner({
          ipAddress: `${subnet}.${octet3}.${octet4}`,
          model: "Avalon A16",
          status: i % 3 === 0 ? "online" : i % 3 === 1 ? "mining" : "offline",
          shelfId,
        });
        ipCounter++;
      }
    };

    await createMinersForShelf(shelf1.id, 4, "10.1");
    await createMinersForShelf(shelf2.id, 3, "10.1");
    await createMinersForShelf(shelf3.id, 4, "10.1");
    await createMinersForShelf(shelf4.id, 5, "10.2");
    await createMinersForShelf(shelf5.id, 3, "10.3");
    await createMinersForShelf(shelf6.id, 3, "10.3");
  }

  const existingProfiles = await storage.getProfiles();
  if (existingProfiles.length === 0) {
    await storage.createProfile({
      name: "Balanced Default",
      description: "Standard factory settings with default chip frequency",
      targetHashrate: 105,
      targetPower: 3200,
      voltageOffset: 0,
      fanSpeed: 60,
      mhzFrequency: 250,
      thermalThreshold: 75,
      powerCapEnabled: false,
      powerCapLimit: 3500,
    });
    await storage.createProfile({
      name: "High Performance",
      description: "Overclocked profile for max hashrate at 300MHz",
      targetHashrate: 115,
      targetPower: 3700,
      voltageOffset: 1,
      fanSpeed: 100,
      mhzFrequency: 300,
      thermalThreshold: 90,
      powerCapEnabled: true,
      powerCapLimit: 3800,
    });
    await storage.createProfile({
      name: "Eco Saver",
      description: "Low power mode at 200MHz for reduced electricity costs",
      targetHashrate: 85,
      targetPower: 3000,
      voltageOffset: -1,
      fanSpeed: 40,
      mhzFrequency: 200,
      thermalThreshold: 65,
      powerCapEnabled: true,
      powerCapLimit: 3200,
    });
  }
}

// Call seed on startup (exported so it can be called from index.ts if needed, or just run here)
// Note: In this template, index.ts imports routes.ts, so top-level code runs. 
// But registerRoutes is called. We should call seed inside registerRoutes or just let it run.
// Better to call it.
seedDatabase().catch(console.error);
