## Packages
recharts | Dashboard analytics and hashrate charts
framer-motion | Smooth transitions and cyber-tech animations
date-fns | Timestamp formatting

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  mono: ["Space Mono", "monospace"],
  display: ["Space Grotesk", "sans-serif"],
}
