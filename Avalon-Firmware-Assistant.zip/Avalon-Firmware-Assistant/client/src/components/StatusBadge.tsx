import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: string;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const normalizedStatus = status.toLowerCase();
  
  const variants: Record<string, string> = {
    online: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
    mining: "bg-primary/10 text-primary border-primary/20 animate-pulse",
    offline: "bg-zinc-500/10 text-zinc-500 border-zinc-500/20",
    error: "bg-red-500/10 text-red-500 border-red-500/20",
    building: "bg-amber-500/10 text-amber-500 border-amber-500/20",
  };

  const className = variants[normalizedStatus] || variants.offline;

  return (
    <span className={cn("px-2.5 py-0.5 rounded-full text-xs font-mono uppercase border", className)}>
      {status}
    </span>
  );
}
