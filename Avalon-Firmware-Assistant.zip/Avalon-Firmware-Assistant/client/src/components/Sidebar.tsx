import { Link, useLocation } from "wouter";
import { LayoutDashboard, Server, Settings2, Cpu, Download, Wrench, Zap, Send } from "lucide-react";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Miners", href: "/miners", icon: Server },
  { name: "Profiles", href: "/profiles", icon: Settings2 },
  { name: "Fleet Deploy", href: "/deploy", icon: Send },
  { name: "Build & Flash", href: "/build", icon: Cpu },
  { name: "Export Config", href: "/export", icon: Download },
  { name: "Firmware SDK", href: "/sdk", icon: Wrench },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="hidden md:flex flex-col w-64 bg-card border-r border-border h-screen sticky top-0 z-[9999]">
      <div className="p-6 border-b border-border/50">
        <div className="flex items-center gap-2">
          <div className="bg-primary/20 p-2 rounded-lg border border-primary/50">
            <Zap className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="font-display font-bold text-lg leading-none tracking-tight">AVALON<span className="text-primary"> by Hut8</span></h1>
            <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-widest mt-1">Firmware Builder</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Link
              key={item.name}
              href={item.href}
              data-testid={`link-nav-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 relative",
                isActive 
                  ? "bg-primary/10 text-primary border border-primary/20" 
                  : "text-muted-foreground hover-elevate"
              )}
            >
              {isActive && (
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary animate-in fade-in slide-in-from-left-2" />
              )}
              <item.icon className={cn("w-5 h-5", isActive ? "text-primary" : "text-muted-foreground")} />
              {item.name}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border/50">
        <div className="bg-secondary/50 rounded-lg p-3 border border-border">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-xs font-mono text-muted-foreground">SYSTEM ONLINE</span>
          </div>
          <div className="text-[10px] text-muted-foreground font-mono">
            v2.4.0-A16-BETA
          </div>
        </div>
      </div>
    </div>
  );
}
