import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Sidebar } from "@/components/Sidebar";

import Dashboard from "@/pages/Dashboard";
import Miners from "@/pages/Miners";
import Profiles from "@/pages/Profiles";
import Build from "@/pages/Build";
import Export from "@/pages/Export";
import FirmwareSDK from "@/pages/FirmwareSDK";
import FleetDeploy from "@/pages/FleetDeploy";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="flex min-h-screen bg-background text-foreground font-sans">
      <Sidebar />
      <main className="flex-1 overflow-auto">
        <div className="container mx-auto p-4 md:p-8 max-w-7xl">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/miners" component={Miners} />
            <Route path="/profiles" component={Profiles} />
            <Route path="/build" component={Build} />
            <Route path="/export" component={Export} />
            <Route path="/deploy" component={FleetDeploy} />
            <Route path="/sdk" component={FirmwareSDK} />
            <Route component={NotFound} />
          </Switch>
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
