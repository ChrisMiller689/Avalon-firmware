import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { type AiOptimizeRequest } from "@shared/schema";

export function useAiOptimize() {
  return useMutation({
    mutationFn: async (data: AiOptimizeRequest) => {
      const res = await fetch(api.ai.optimize.path, {
        method: api.ai.optimize.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("AI Optimization failed");
      return api.ai.optimize.responses[200].parse(await res.json());
    },
  });
}
