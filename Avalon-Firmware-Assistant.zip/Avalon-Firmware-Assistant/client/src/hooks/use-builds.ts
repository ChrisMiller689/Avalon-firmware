import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { type InsertBuildJob } from "@shared/schema";

export function useBuildJobs() {
  return useQuery({
    queryKey: [api.builds.list.path],
    queryFn: async () => {
      const res = await fetch(api.builds.list.path);
      if (!res.ok) throw new Error("Failed to fetch build jobs");
      return api.builds.list.responses[200].parse(await res.json());
    },
    refetchInterval: 3000, // Poll frequently for build status
  });
}

export function useCreateBuildJob() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertBuildJob) => {
      const res = await fetch(api.builds.create.path, {
        method: api.builds.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create build job");
      return api.builds.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.builds.list.path] });
    },
  });
}
