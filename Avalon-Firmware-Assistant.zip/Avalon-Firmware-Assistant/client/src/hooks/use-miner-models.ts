import { useQuery } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import type { MinerModel } from "@shared/schema";

export function useMinerModels() {
  return useQuery<MinerModel[]>({
    queryKey: [api.minerModels.list.path],
    queryFn: async () => {
      const res = await fetch(api.minerModels.list.path);
      if (!res.ok) throw new Error("Failed to fetch miner models");
      return res.json();
    },
  });
}

export function useMinerModel(id: number | null | undefined) {
  return useQuery<MinerModel>({
    queryKey: [api.minerModels.get.path, id],
    queryFn: async () => {
      if (!id) throw new Error("No model ID");
      const url = buildUrl(api.minerModels.get.path, { id });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch miner model");
      return res.json();
    },
    enabled: !!id,
  });
}
