import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertMiner, type Miner } from "@shared/schema";

// GET /api/miners
export function useMiners() {
  return useQuery({
    queryKey: [api.miners.list.path],
    queryFn: async () => {
      const res = await fetch(api.miners.list.path);
      if (!res.ok) throw new Error("Failed to fetch miners");
      return api.miners.list.responses[200].parse(await res.json());
    },
    // Poll every 5 seconds for status updates
    refetchInterval: 5000,
  });
}

// GET /api/miners/:id
export function useMiner(id: number) {
  return useQuery({
    queryKey: [api.miners.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.miners.get.path, { id });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch miner");
      return api.miners.get.responses[200].parse(await res.json());
    },
  });
}

// POST /api/miners
export function useCreateMiner() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertMiner) => {
      const res = await fetch(api.miners.create.path, {
        method: api.miners.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create miner");
      return api.miners.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.miners.list.path] });
    },
  });
}

// PUT /api/miners/:id
export function useUpdateMiner() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, ...data }: Partial<InsertMiner> & { id: number }) => {
      const url = buildUrl(api.miners.update.path, { id });
      const res = await fetch(url, {
        method: api.miners.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update miner");
      return api.miners.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.miners.list.path] });
    },
  });
}

// DELETE /api/miners/:id
export function useDeleteMiner() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.miners.delete.path, { id });
      const res = await fetch(url, { method: api.miners.delete.method });
      if (!res.ok) throw new Error("Failed to delete miner");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.miners.list.path] });
    },
  });
}
