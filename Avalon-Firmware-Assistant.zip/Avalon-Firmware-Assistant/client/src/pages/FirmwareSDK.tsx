import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useProfiles } from "@/hooks/use-profiles";
import { useToast } from "@/hooks/use-toast";
import {
  Terminal, GitBranch, BookOpen, Cpu, Settings, Package,
  ExternalLink, Copy, ChevronRight, Wrench, Layers,
  FileCode, Server, Zap, HardDrive, Fan, Thermometer
} from "lucide-react";
import type { Profile } from "@shared/schema";

const SDK_REPOS = [
  {
    name: "cgminer",
    description: "Canaan's fork of cgminer - the core mining software for Avalon ASICs. Handles pool communication, work distribution, and hardware control.",
    url: "https://github.com/Canaan-Creative/cgminer",
    language: "C",
    branch: "avalon10",
    tags: ["mining", "stratum", "hardware-control"],
  },
  {
    name: "cgminer-openwrt-packages",
    description: "OpenWrt build packages for cgminer integration. Used to package cgminer into the Avalon firmware image alongside the Linux system.",
    url: "https://github.com/Canaan-Creative/cgminer-openwrt-packages",
    language: "Shell",
    branch: "master",
    tags: ["openwrt", "packaging", "build-system"],
  },
  {
    name: "MM (Miner Manager)",
    description: "FPGA-based task generator firmware. Generates Bitcoin work tasks inside the FPGA using Stratum protocol, reports valid nonces back to cgminer.",
    url: "https://github.com/Canaan-Creative/MM",
    language: "Verilog / C",
    branch: "master",
    tags: ["fpga", "verilog", "task-generation"],
  },
  {
    name: "luci (Web GUI)",
    description: "LuCI-based web interface for Avalon miners. Provides the browser-accessible management panel running on OpenWrt.",
    url: "https://github.com/Canaan-Creative/luci",
    language: "Lua",
    branch: "master",
    tags: ["webgui", "openwrt", "luci"],
  },
  {
    name: "avalon10-docs",
    description: "Developer API documentation for Avalon 10 series. Contains Universal and Privileged API references for direct miner control.",
    url: "https://github.com/Canaan-Creative/avalon10-docs",
    language: "Documentation",
    branch: "master",
    tags: ["api", "docs", "avalon10"],
  },
  {
    name: "fms-core",
    description: "Fleet Management System core library. Python functions for communicating with and controlling multiple Avalon miners at scale.",
    url: "https://github.com/Canaan-Creative/fms-core",
    language: "Python",
    branch: "master",
    tags: ["fleet", "management", "python"],
  },
];

const API_COMMANDS = [
  { cmd: "asccount", desc: "Returns number of ASC devices", category: "Universal", example: '{"command":"asccount"}' },
  { cmd: "asc", desc: "Returns ASC device details by index", category: "Universal", example: '{"command":"asc","parameter":"0"}' },
  { cmd: "pools", desc: "Returns all configured pool details", category: "Universal", example: '{"command":"pools"}' },
  { cmd: "summary", desc: "Returns overall mining summary", category: "Universal", example: '{"command":"summary"}' },
  { cmd: "stats", desc: "Returns detailed device statistics", category: "Universal", example: '{"command":"stats"}' },
  { cmd: "coin", desc: "Returns current block and network info", category: "Universal", example: '{"command":"coin"}' },
  { cmd: "ascset", desc: "Set ASC parameter (freq, voltage)", category: "Privileged", example: '{"command":"ascset","parameter":"0,avalon10-freq,500"}' },
  { cmd: "avalon10-factory", desc: "Reset to factory defaults", category: "Privileged", example: '{"command":"ascset","parameter":"0,avalon10-factory"}' },
  { cmd: "avalon10-reboot", desc: "Reboot the controller board", category: "Privileged", example: '{"command":"ascset","parameter":"0,avalon10-reboot"}' },
];

const BUILD_STEPS = [
  {
    step: 1,
    title: "Set Up Build Environment",
    description: "Install OpenWrt SDK and Canaan cross-compilation toolchain on a Linux host.",
    commands: [
      "git clone https://github.com/Canaan-Creative/cgminer-openwrt-packages.git",
      "# Install OpenWrt build dependencies",
      "sudo apt-get install build-essential libncurses5-dev gawk git subversion libssl-dev",
      "# Download OpenWrt SDK for your target architecture",
    ],
    status: "setup",
  },
  {
    step: 2,
    title: "Configure cgminer Source",
    description: "Clone Canaan's cgminer fork and configure it for the Avalon A16 target with your tuning parameters.",
    commands: [
      "git clone https://github.com/Canaan-Creative/cgminer.git",
      "cd cgminer && git checkout avalon10",
      "./autogen.sh",
      "./configure --enable-avalon10 --without-curses",
    ],
    status: "source",
  },
  {
    step: 3,
    title: "Apply Custom Configuration",
    description: "Inject your Avalon by Hut8 profile settings into the cgminer configuration. Use the exported .conf file from the Export page.",
    commands: [
      "# Copy your exported Avalon by Hut8 config",
      "cp your_profile_config.conf /etc/config/cgminer",
      "# Or apply parameters directly:",
      "avalon10-freq = {mhzFrequency}",
      "avalon10-voltage-level = {voltageOffset}",
      "avalon10-fan-pct = {fanSpeed}",
    ],
    status: "config",
  },
  {
    step: 4,
    title: "Build Firmware Image",
    description: "Compile the OpenWrt firmware image with cgminer and custom configuration baked in.",
    commands: [
      "cd openwrt",
      "make menuconfig  # Select Avalon target & cgminer package",
      "make -j$(nproc) V=s",
      "# Output: bin/targets/*/openwrt-*-sysupgrade.bin",
    ],
    status: "build",
  },
  {
    step: 5,
    title: "Flash to Controller",
    description: "Upload the compiled firmware to the Avalon control board via web interface or TFTP.",
    commands: [
      "# Via Web GUI (recommended):",
      "# Navigate to http://<miner-ip> -> System -> Firmware Upgrade",
      "# Upload the sysupgrade.bin file",
      "",
      "# Via TFTP (advanced):",
      "tftp -i <miner-ip> PUT openwrt-sysupgrade.bin",
    ],
    status: "flash",
  },
];

const CGMINER_OPTIONS = {
  general: [
    { key: "api-listen", type: "boolean", default: "true", desc: "Enable cgminer RPC API listener" },
    { key: "api-network", type: "boolean", default: "false", desc: "Allow non-local API connections" },
    { key: "api-allow", type: "string", default: "W:127.0.0.1", desc: "API access control (W=write, R=read)" },
    { key: "log", type: "integer", default: "5", desc: "Logging interval in seconds" },
    { key: "queue", type: "integer", default: "9999", desc: "Maximum work queue depth" },
    { key: "scan-time", type: "integer", default: "10", desc: "Seconds between device scans" },
    { key: "expiry", type: "integer", default: "120", desc: "Work expiry timeout in seconds" },
  ],
  avalon10: [
    { key: "avalon10-freq", type: "integer", default: "250", desc: "Chip frequency in MHz (200-400)" },
    { key: "avalon10-voltage-level", type: "integer", default: "0", desc: "Voltage offset level (-2 to +1)" },
    { key: "avalon10-fan-pct", type: "integer", default: "100", desc: "Fan speed percentage (0-100)" },
    { key: "avalon10-target-temp", type: "integer", default: "75", desc: "Target chip temperature in Celsius" },
    { key: "avalon10-target-freq", type: "integer", default: "250", desc: "Target operating frequency (auto-adjust)" },
  ],
  pool: [
    { key: "url", type: "string", default: "stratum+tcp://pool:port", desc: "Mining pool Stratum URL" },
    { key: "user", type: "string", default: "wallet.worker", desc: "Pool username (wallet address)" },
    { key: "pass", type: "string", default: "x", desc: "Pool password (usually 'x')" },
    { key: "no-submit-stale", type: "boolean", default: "false", desc: "Reject stale shares" },
  ],
};

export default function FirmwareSDK() {
  const { data: profiles } = useProfiles();
  const { toast } = useToast();
  const [selectedProfile, setSelectedProfile] = useState<Profile | null>(null);
  const [apiFilter, setApiFilter] = useState<"all" | "Universal" | "Privileged">("all");

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied", description: "Command copied to clipboard." });
  };

  const generateCgminerConf = () => {
    const p = selectedProfile;
    const lines = [
      `# cgminer.conf - Generated by Avalon by Hut8`,
      `# Profile: ${p ? p.name : "Default"}`,
      `# Generated: ${new Date().toISOString()}`,
      ``,
      `{`,
      `  "api-listen": true,`,
      `  "api-network": false,`,
      `  "api-allow": "W:127.0.0.1",`,
      `  "queue": 9999,`,
      `  "scan-time": 10,`,
      `  "expiry": 120,`,
      `  "log": 5,`,
      `  "avalon10-freq": "${p?.mhzFrequency || 250}",`,
      `  "avalon10-voltage-level": "${p?.voltageOffset || 0}",`,
      `  "avalon10-fan-pct": "${p?.fanSpeed || 100}",`,
      `  "avalon10-target-temp": "75",`,
      `  "pools": [`,
      `    {`,
      `      "url": "stratum+tcp://YOUR_POOL:PORT",`,
      `      "user": "YOUR_WALLET.worker1",`,
      `      "pass": "x"`,
      `    }`,
      `  ]`,
      `}`,
    ];
    return lines.join("\n");
  };

  const downloadCgminerConf = () => {
    const content = generateCgminerConf();
    const blob = new Blob([content], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "cgminer.conf";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast({ title: "Downloaded", description: "cgminer.conf saved." });
  };

  const filteredCommands = apiFilter === "all"
    ? API_COMMANDS
    : API_COMMANDS.filter((c) => c.category === apiFilter);

  return (
    <div className="space-y-8 max-w-6xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-primary/10 mb-4 border border-primary/20">
          <Wrench className="w-8 h-8 text-primary" />
        </div>
        <h2 className="text-3xl font-bold tracking-tight" data-testid="text-sdk-title">Firmware SDK</h2>
        <p className="text-muted-foreground mt-2 max-w-xl mx-auto">
          Developer tools, SDK resources, and build pipeline for Avalon A16 firmware. Combines Canaan's open-source tooling with your Avalon by Hut8 configurations.
        </p>
      </div>

      <Tabs defaultValue="resources" className="w-full">
        <TabsList className="w-full grid grid-cols-4">
          <TabsTrigger value="resources" data-testid="tab-resources"><BookOpen className="w-4 h-4 mr-2" />SDK Resources</TabsTrigger>
          <TabsTrigger value="config" data-testid="tab-config"><Settings className="w-4 h-4 mr-2" />Config Builder</TabsTrigger>
          <TabsTrigger value="api" data-testid="tab-api"><Terminal className="w-4 h-4 mr-2" />API Reference</TabsTrigger>
          <TabsTrigger value="pipeline" data-testid="tab-pipeline"><Layers className="w-4 h-4 mr-2" />Build Pipeline</TabsTrigger>
        </TabsList>

        <TabsContent value="resources" className="mt-6 space-y-4">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <h3 className="text-lg font-semibold">Canaan Open-Source Repositories</h3>
            <Badge variant="secondary">
              <GitBranch className="w-3 h-3 mr-1" />
              {SDK_REPOS.length} repos
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {SDK_REPOS.map((repo) => (
              <Card key={repo.name} className="p-5 space-y-3" data-testid={`card-repo-${repo.name.toLowerCase().replace(/\s+/g, '-')}`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2 min-w-0">
                    <FileCode className="w-5 h-5 text-primary shrink-0" />
                    <h4 className="font-semibold truncate">{repo.name}</h4>
                  </div>
                  <Badge variant="outline" className="shrink-0 text-xs">{repo.language}</Badge>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">{repo.description}</p>
                <div className="flex items-center gap-2 flex-wrap">
                  {repo.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                  ))}
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(repo.url, "_blank")}
                    data-testid={`button-repo-${repo.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <ExternalLink className="w-3 h-3 mr-1" />
                    View on GitHub
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(`git clone ${repo.url}.git`)}
                    data-testid={`button-clone-${repo.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <Copy className="w-3 h-3 mr-1" />
                    Clone URL
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          <Card className="p-5 mt-6">
            <h4 className="font-semibold mb-3 flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-primary" />
              Legacy Firmware Downloads
            </h4>
            <p className="text-sm text-muted-foreground mb-3">
              Canaan's AWS archive for older Avalon models (Avalon 3, 4, 6) and MCU firmware binaries.
            </p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open("https://canaanio-downloads.s3.amazonaws.com/downloads/index-old.html", "_blank")}
              data-testid="button-legacy-downloads"
            >
              <ExternalLink className="w-3 h-3 mr-1" />
              Open Archive
            </Button>
          </Card>
        </TabsContent>

        <TabsContent value="config" className="mt-6 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1 space-y-4">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Load from Profile</h3>
              {profiles && profiles.length > 0 ? (
                <div className="space-y-2">
                  {profiles.map((p) => (
                    <Card
                      key={p.id}
                      className={`p-3 cursor-pointer transition-all duration-200 ${
                        selectedProfile?.id === p.id ? "border-primary/50 bg-primary/5" : "hover-elevate"
                      }`}
                      onClick={() => setSelectedProfile(p)}
                      data-testid={`card-config-profile-${p.id}`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${selectedProfile?.id === p.id ? "bg-primary" : "bg-muted-foreground/30"}`} />
                        <span className="font-medium text-sm truncate">{p.name}</span>
                      </div>
                      <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground font-mono flex-wrap">
                        <span>{p.mhzFrequency || 250}MHz</span>
                        <span>{p.fanSpeed}%</span>
                        <span>{p.targetPower}W</span>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="p-4">
                  <p className="text-sm text-muted-foreground text-center">No profiles. Create one in Profiles.</p>
                </Card>
              )}
            </div>

            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between gap-4 flex-wrap">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">cgminer.conf Reference</h3>
                <Button size="sm" onClick={downloadCgminerConf} data-testid="button-download-cgminer-conf">
                  <Package className="w-3 h-3 mr-1" />
                  Download cgminer.conf
                </Button>
              </div>

              <Card className="overflow-hidden">
                <div className="bg-secondary/30 px-4 py-2 border-b border-border flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs font-mono text-muted-foreground">cgminer.conf</span>
                </div>
                <pre className="p-4 text-sm font-mono overflow-x-auto text-foreground leading-relaxed" data-testid="text-cgminer-conf-preview">
                  {generateCgminerConf()}
                </pre>
              </Card>

              <div className="space-y-4">
                <h4 className="text-sm font-semibold flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-primary" />
                  Avalon10 Parameters
                </h4>
                <div className="space-y-2">
                  <div className="grid grid-cols-[minmax(0,1fr)_auto_auto_minmax(0,2fr)] gap-x-4 gap-y-0 py-2 px-3 border-b border-border">
                    <span className="font-semibold text-xs text-muted-foreground">Parameter</span>
                    <span className="font-semibold text-xs text-muted-foreground">Type</span>
                    <span className="font-semibold text-xs text-muted-foreground">Default</span>
                    <span className="font-semibold text-xs text-muted-foreground">Description</span>
                  </div>
                  {CGMINER_OPTIONS.avalon10.map((opt) => (
                    <div key={opt.key} className="grid grid-cols-[minmax(0,1fr)_auto_auto_minmax(0,2fr)] gap-x-4 gap-y-0 py-2 px-3 border-b border-border/50">
                      <span className="font-mono text-xs">{opt.key}</span>
                      <span className="text-xs text-muted-foreground">{opt.type}</span>
                      <span className="font-mono text-xs">{opt.default}</span>
                      <span className="text-xs text-muted-foreground">{opt.desc}</span>
                    </div>
                  ))}
                </div>

                <h4 className="text-sm font-semibold flex items-center gap-2 pt-2">
                  <Server className="w-4 h-4 text-primary" />
                  General & Pool Parameters
                </h4>
                <div className="space-y-2">
                  <div className="grid grid-cols-[minmax(0,1fr)_auto_auto_minmax(0,2fr)] gap-x-4 gap-y-0 py-2 px-3 border-b border-border">
                    <span className="font-semibold text-xs text-muted-foreground">Parameter</span>
                    <span className="font-semibold text-xs text-muted-foreground">Type</span>
                    <span className="font-semibold text-xs text-muted-foreground">Default</span>
                    <span className="font-semibold text-xs text-muted-foreground">Description</span>
                  </div>
                  {[...CGMINER_OPTIONS.general, ...CGMINER_OPTIONS.pool].map((opt) => (
                    <div key={opt.key} className="grid grid-cols-[minmax(0,1fr)_auto_auto_minmax(0,2fr)] gap-x-4 gap-y-0 py-2 px-3 border-b border-border/50">
                      <span className="font-mono text-xs">{opt.key}</span>
                      <span className="text-xs text-muted-foreground">{opt.type}</span>
                      <span className="font-mono text-xs">{opt.default}</span>
                      <span className="text-xs text-muted-foreground">{opt.desc}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="api" className="mt-6 space-y-6">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h3 className="text-lg font-semibold">Avalon 10 cgminer API</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Send commands over TCP to port 4028 on your miner. Default credentials: root / (no password).
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={apiFilter === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setApiFilter("all")}
                data-testid="button-filter-all"
              >
                All
              </Button>
              <Button
                variant={apiFilter === "Universal" ? "default" : "outline"}
                size="sm"
                onClick={() => setApiFilter("Universal")}
                data-testid="button-filter-universal"
              >
                Universal
              </Button>
              <Button
                variant={apiFilter === "Privileged" ? "default" : "outline"}
                size="sm"
                onClick={() => setApiFilter("Privileged")}
                data-testid="button-filter-privileged"
              >
                Privileged
              </Button>
            </div>
          </div>

          <Card className="p-4 bg-amber-500/5 border-amber-500/20">
            <p className="text-sm text-muted-foreground">
              <strong className="text-foreground">Warning:</strong> Privileged API commands can void warranty and may cause hardware damage if used incorrectly.
              They are only available on privileged firmware builds. Use at your own risk.
            </p>
          </Card>

          <div className="space-y-3">
            {filteredCommands.map((cmd) => (
              <Card key={cmd.cmd} className="p-4" data-testid={`card-api-${cmd.cmd}`}>
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono font-bold text-sm">{cmd.cmd}</span>
                      <Badge variant={cmd.category === "Privileged" ? "destructive" : "secondary"} className="text-xs">
                        {cmd.category}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{cmd.desc}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => copyToClipboard(cmd.example)}
                    data-testid={`button-copy-api-${cmd.cmd}`}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
                <div className="mt-3 bg-secondary/30 rounded-lg p-3 flex items-center gap-2">
                  <ChevronRight className="w-3 h-3 text-muted-foreground shrink-0" />
                  <code className="text-xs font-mono text-foreground break-all">{cmd.example}</code>
                </div>
                <div className="mt-2 text-xs text-muted-foreground font-mono">
                  echo '{cmd.example}' | nc &lt;miner-ip&gt; 4028
                </div>
              </Card>
            ))}
          </div>

          <Card className="p-5">
            <h4 className="font-semibold mb-3 flex items-center gap-2">
              <Terminal className="w-4 h-4 text-primary" />
              Quick Test Connection
            </h4>
            <p className="text-sm text-muted-foreground mb-3">
              Run this from any Linux/macOS terminal to verify API access to your miner:
            </p>
            <div className="bg-secondary/30 rounded-lg p-4 font-mono text-sm space-y-1">
              <div className="flex items-center justify-between gap-2">
                <code>echo '{`{"command":"summary"}`}' | nc YOUR_MINER_IP 4028</code>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => copyToClipboard(`echo '{"command":"summary"}' | nc YOUR_MINER_IP 4028`)}
                  data-testid="button-copy-test-cmd"
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="pipeline" className="mt-6 space-y-6">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h3 className="text-lg font-semibold">Firmware Build Pipeline</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Step-by-step guide to compile custom Avalon firmware with your Avalon by Hut8 profiles baked in.
              </p>
            </div>
            {selectedProfile && (
              <Badge variant="secondary">
                <Zap className="w-3 h-3 mr-1" />
                Using: {selectedProfile.name}
              </Badge>
            )}
          </div>

          {!selectedProfile && profiles && profiles.length > 0 && (
            <Card className="p-4 bg-primary/5 border-primary/20">
              <p className="text-sm text-muted-foreground">
                Select a profile in the <strong>Config Builder</strong> tab to pre-fill build parameters with your tuning settings.
              </p>
            </Card>
          )}

          <div className="space-y-6">
            {BUILD_STEPS.map((step, idx) => (
              <div key={step.step} className="flex gap-4" data-testid={`step-build-${step.step}`}>
                <div className="flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center text-sm font-bold text-primary">
                    {step.step}
                  </div>
                  {idx < BUILD_STEPS.length - 1 && (
                    <div className="w-px flex-1 bg-border/50 mt-2" />
                  )}
                </div>
                <Card className="flex-1 p-5 space-y-3">
                  <h4 className="font-semibold">{step.title}</h4>
                  <p className="text-sm text-muted-foreground">{step.description}</p>
                  <div className="bg-secondary/30 rounded-lg p-4 space-y-1 font-mono text-xs">
                    {step.commands.map((cmd, i) => {
                      let displayCmd = cmd;
                      if (selectedProfile) {
                        displayCmd = displayCmd
                          .replace("{mhzFrequency}", String(selectedProfile.mhzFrequency || 250))
                          .replace("{voltageOffset}", String(selectedProfile.voltageOffset || 0))
                          .replace("{fanSpeed}", String(selectedProfile.fanSpeed || 100));
                      }
                      return (
                        <div key={i} className={`flex items-center gap-2 ${cmd.startsWith("#") ? "text-muted-foreground" : "text-foreground"}`}>
                          {!cmd.startsWith("#") && cmd.length > 0 && (
                            <ChevronRight className="w-3 h-3 text-muted-foreground shrink-0" />
                          )}
                          <span className="break-all">{displayCmd}</span>
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard(step.commands.filter((c) => !c.startsWith("#") && c.length > 0).join("\n"))}
                      data-testid={`button-copy-step-${step.step}`}
                    >
                      <Copy className="w-3 h-3 mr-1" />
                      Copy Commands
                    </Button>
                  </div>
                </Card>
              </div>
            ))}
          </div>

          <Card className="p-5">
            <h4 className="font-semibold mb-3 flex items-center gap-2">
              <Thermometer className="w-4 h-4 text-amber-500" />
              Safety Notes
            </h4>
            <ul className="text-sm text-muted-foreground space-y-2 list-disc list-inside">
              <li>Always test custom firmware on a single miner before fleet deployment</li>
              <li>Keep a backup of stock firmware for recovery</li>
              <li>Monitor temperatures closely after flashing new settings</li>
              <li>Frequencies above 700 MHz may cause thermal throttling or damage</li>
              <li>Contact Canaan support for A13/A15/A16 specialized firmware</li>
            </ul>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
