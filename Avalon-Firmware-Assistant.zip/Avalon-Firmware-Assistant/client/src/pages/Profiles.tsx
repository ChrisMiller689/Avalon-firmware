import { useState, useEffect, useCallback, useMemo } from "react";
import { useProfiles, useCreateProfile, useUpdateProfile, useDeleteProfile } from "@/hooks/use-profiles";
import { useAiOptimize } from "@/hooks/use-ai";
import { useMinerModels } from "@/hooks/use-miner-models";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Plus, Zap, Bot, Trash2, Edit, Cpu, Thermometer, BatteryCharging, Lock, Target, Gauge, Flame, Activity, Droplets, Wind, Waves } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertProfileSchema, type InsertProfile, type MinerModel } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

function getCoolingIcon(type: string) {
  if (type === "hydro") return Droplets;
  if (type === "immersion") return Waves;
  return Wind;
}

function getCoolingLabel(type: string) {
  if (type === "hydro") return "Hydro";
  if (type === "immersion") return "Immersion";
  return "Air";
}

function getCoolingColor(type: string) {
  if (type === "hydro") return "text-blue-400";
  if (type === "immersion") return "text-purple-400";
  return "text-emerald-400";
}

const AUTO_TUNE_MODES = [
  { value: "none", label: "Manual", icon: Zap, description: "All settings manual" },
  { value: "power", label: "Power Target", icon: BatteryCharging, description: "Lock power, auto-tune rest" },
  { value: "hashrate", label: "Hashrate Target", icon: Gauge, description: "Lock hashrate, auto-tune rest" },
  { value: "efficiency", label: "Efficiency Target", icon: Activity, description: "Lock TH/J, auto-tune rest" },
  { value: "temperature", label: "Temperature Target", icon: Flame, description: "Lock temp, auto-tune rest" },
] as const;

interface ModelSpecs {
  minFreq: number; maxFreq: number; defFreq: number;
  minPow: number; maxPow: number; defPow: number;
  minTherm: number; maxTherm: number; defTherm: number;
  minVolt: number; maxVolt: number;
  defHash: number; hasFans: boolean;
}

const DEFAULT_SPECS: ModelSpecs = {
  minFreq: 200, maxFreq: 400, defFreq: 250,
  minPow: 3000, maxPow: 4000, defPow: 3200,
  minTherm: 10, maxTherm: 100, defTherm: 85,
  minVolt: -2, maxVolt: 1,
  defHash: 105, hasFans: true,
};

function modelToSpecs(m: MinerModel | null | undefined): ModelSpecs {
  if (!m) return DEFAULT_SPECS;
  return {
    minFreq: m.minFrequency, maxFreq: m.maxFrequency, defFreq: m.defaultFrequency,
    minPow: m.minPower, maxPow: m.maxPower, defPow: m.defaultPower,
    minTherm: m.minThermal, maxTherm: m.maxThermal, defTherm: m.defaultThermal,
    minVolt: m.minVoltageOffset, maxVolt: m.maxVoltageOffset,
    defHash: m.defaultHashrate, hasFans: m.hasFans,
  };
}

function computeAutoTune(mode: string, target: number, specs: ModelSpecs = DEFAULT_SPECS) {
  if (mode === "none" || !target) return null;
  const { minFreq, maxFreq, minPow, maxPow, minTherm, maxTherm, minVolt, maxVolt, defHash } = specs;
  const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));
  const freqRange = maxFreq - minFreq;
  const powRange = maxPow - minPow;

  if (mode === "power") {
    const watts = clamp(target, minPow, maxPow);
    const ratio = (watts - minPow) / powRange;
    const mhz = Math.round(clamp(minFreq + ratio * freqRange, minFreq, maxFreq));
    const hashrate = Math.round(clamp(defHash * 0.6 + ratio * defHash * 0.8, defHash * 0.5, defHash * 1.5));
    const thermal = Math.round(clamp(65 + ratio * 25, minTherm, maxTherm));
    const fan = specs.hasFans ? Math.round(clamp(60 + ratio * 40, 60, 100)) : 0;
    const voltage = ratio < 0.3 ? minVolt : ratio < 0.5 ? Math.round((minVolt + maxVolt) / 3) : ratio < 0.8 ? 0 : maxVolt;
    return { targetPower: watts, mhzFrequency: mhz, targetHashrate: hashrate, thermalThreshold: thermal, fanSpeed: fan, voltageOffset: voltage };
  }

  if (mode === "hashrate") {
    const maxHash = Math.round(defHash * 1.5);
    const minHash = Math.round(defHash * 0.5);
    const hash = clamp(target, minHash, maxHash);
    const ratio = (hash - minHash) / (maxHash - minHash);
    const mhz = Math.round(clamp(minFreq + ratio * freqRange, minFreq, maxFreq));
    const watts = Math.round(clamp(minPow + ratio * powRange, minPow, maxPow) / 10) * 10;
    const thermal = Math.round(clamp(65 + ratio * 25, minTherm, maxTherm));
    const fan = specs.hasFans ? Math.round(clamp(60 + ratio * 40, 60, 100)) : 0;
    const voltage = ratio < 0.3 ? minVolt : ratio < 0.5 ? Math.round((minVolt + maxVolt) / 3) : ratio < 0.8 ? 0 : maxVolt;
    return { targetHashrate: hash, mhzFrequency: mhz, targetPower: watts, thermalThreshold: thermal, fanSpeed: fan, voltageOffset: voltage };
  }

  if (mode === "efficiency") {
    const thj = clamp(target, 10, 50);
    const effRatio = (thj - 10) / 40;
    const mhz = Math.round(clamp(minFreq + freqRange * 0.3 + (1 - effRatio) * freqRange * 0.4, minFreq, maxFreq));
    const watts = Math.round(clamp(minPow + (1 - effRatio) * powRange * 0.5, minPow, maxPow) / 10) * 10;
    const hashrate = Math.round(clamp(defHash * 0.7 + (1 - effRatio) * defHash * 0.5, defHash * 0.5, defHash * 1.3));
    const thermal = Math.round(clamp(70 + effRatio * 10, minTherm, maxTherm));
    const fan = specs.hasFans ? Math.round(clamp(70 + (1 - effRatio) * 20, 60, 100)) : 0;
    const voltage = effRatio < 0.3 ? Math.round((minVolt + maxVolt) / 3) : effRatio < 0.7 ? 0 : maxVolt;
    return { targetHashrate: hashrate, mhzFrequency: mhz, targetPower: watts, thermalThreshold: thermal, fanSpeed: fan, voltageOffset: voltage };
  }

  if (mode === "temperature") {
    const temp = clamp(target, minTherm, maxTherm);
    const tempRatio = (temp - minTherm) / (maxTherm - minTherm);
    const mhz = Math.round(clamp(minFreq + tempRatio * freqRange * 0.75, minFreq, maxFreq));
    const watts = Math.round(clamp(minPow + tempRatio * powRange * 0.8, minPow, maxPow) / 10) * 10;
    const hashrate = Math.round(clamp(defHash * 0.5 + tempRatio * defHash * 0.8, defHash * 0.4, defHash * 1.4));
    const fan = specs.hasFans ? Math.round(clamp(100 - tempRatio * 40, 60, 100)) : 0;
    const voltage = tempRatio < 0.3 ? minVolt : tempRatio < 0.6 ? Math.round((minVolt + maxVolt) / 3) : tempRatio < 0.85 ? 0 : maxVolt;
    return { thermalThreshold: temp, mhzFrequency: mhz, targetPower: watts, targetHashrate: hashrate, fanSpeed: fan, voltageOffset: voltage };
  }

  return null;
}

export default function Profiles() {
  const { data: profiles, isLoading } = useProfiles();
  const { data: models } = useMinerModels();
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const modelMap = useMemo(() => {
    const map = new Map<number, MinerModel>();
    models?.forEach(m => map.set(m.id, m));
    return map;
  }, [models]);

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center flex-wrap gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight" data-testid="text-profiles-title">Tuning Profiles</h2>
          <p className="text-muted-foreground">Configure performance presets for your fleet.</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-profile">
              <Plus className="w-4 h-4 mr-2" /> Create Profile
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Tuning Profile</DialogTitle>
            </DialogHeader>
            <ProfileForm onSuccess={() => setIsCreateOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {profiles?.map((profile) => (
          <ProfileCard key={profile.id} profile={profile} model={profile.modelId ? modelMap.get(profile.modelId) : undefined} />
        ))}
        {profiles?.length === 0 && !isLoading && (
          <div className="col-span-full flex flex-col items-center justify-center p-12 border border-dashed border-border rounded-xl">
            <Zap className="w-12 h-12 text-muted-foreground mb-4 opacity-20" />
            <h3 className="text-lg font-medium">No Profiles Created</h3>
            <p className="text-muted-foreground text-sm max-w-sm text-center mt-2">
              Create a tuning profile to configure voltage, frequency, and fan speeds for your miners.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function ProfileCard({ profile, model }: { profile: any; model?: MinerModel }) {
  const { toast } = useToast();
  const deleteMutation = useDeleteProfile();
  const [isEditOpen, setIsEditOpen] = useState(false);

  const handleDelete = async () => {
    if (confirm("Delete this profile?")) {
      await deleteMutation.mutateAsync(profile.id);
      toast({ title: "Profile deleted" });
    }
  };

  const CoolingIcon = model ? getCoolingIcon(model.coolingType) : Wind;

  return (
    <Card className="flex flex-col h-full group" data-testid={`card-profile-${profile.id}`}>
      <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0 pb-2">
        <div className="min-w-0">
          <CardTitle className="text-xl font-bold tracking-tight">{profile.name}</CardTitle>
          {model && (
            <div className="flex items-center gap-1.5 mt-1">
              <CoolingIcon className={`w-3 h-3 shrink-0 ${getCoolingColor(model.coolingType)}`} />
              <span className="text-xs font-mono text-muted-foreground truncate" data-testid={`text-profile-model-${profile.id}`}>{model.name}</span>
              <Badge variant="secondary" className="text-[10px] shrink-0">{getCoolingLabel(model.coolingType)}</Badge>
            </div>
          )}
          <CardDescription className="line-clamp-2 min-h-[40px] mt-1">
            {profile.description || "No description provided."}
          </CardDescription>
        </div>
        <div className="flex items-center gap-1.5 shrink-0 flex-wrap">
          {profile.autoTuneMode && profile.autoTuneMode !== "none" && (
            <div className="bg-purple-500/10 text-purple-400 border border-purple-500/20 px-2 py-0.5 rounded text-[10px] font-mono uppercase flex items-center gap-1">
              <Target className="w-3 h-3" /> {profile.autoTuneMode}
            </div>
          )}
          {profile.isAiOptimized && (
            <div className="bg-purple-500/10 text-purple-400 border border-purple-500/20 px-2 py-0.5 rounded text-[10px] font-mono uppercase flex items-center gap-1">
              <Bot className="w-3 h-3" /> AI
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent className="flex-1 space-y-4">
        {(() => {
          const s = modelToSpecs(model);
          const thermRange = s.maxTherm - s.minTherm;
          const freqRange = s.maxFreq - s.minFreq;
          const powRange = s.maxPow - s.minPow;
          return (
            <>
              <div>
                <div className="flex justify-between text-xs text-muted-foreground mb-1 uppercase tracking-wider">
                  <span>Thermal Threshold</span>
                  <span className={`font-mono ${(profile.thermalThreshold || s.defTherm) >= 90 ? 'text-red-500' : (profile.thermalThreshold || s.defTherm) >= 75 ? 'text-amber-500' : 'text-emerald-500'}`}>{profile.thermalThreshold || s.defTherm}°C</span>
                </div>
                <div className="h-1 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-red-500" style={{ width: `${Math.min(100, Math.max(0, ((profile.thermalThreshold || s.defTherm) - s.minTherm) / thermRange * 100))}%` }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs text-muted-foreground mb-1 uppercase tracking-wider">
                  <span>Frequency</span>
                  <span className="text-foreground font-mono text-cyan-500">{profile.mhzFrequency || s.defFreq} MHz</span>
                </div>
                <div className="h-1 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-cyan-500" style={{ width: `${Math.min(100, Math.max(0, ((profile.mhzFrequency || s.defFreq) - s.minFreq) / freqRange * 100))}%` }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs text-muted-foreground mb-1 uppercase tracking-wider">
                  <span>Power Draw</span>
                  <span className="text-foreground font-mono text-emerald-500">{((profile.targetPower || s.defPow) / 1000).toFixed(2)} kW</span>
                </div>
                <div className="h-1 bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500" style={{ width: `${Math.min(100, Math.max(0, ((profile.targetPower || s.defPow) - s.minPow) / powRange * 100))}%` }} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 mt-4">
                <div className="bg-secondary/30 p-2 rounded border border-border/50 text-center">
                  <span className="block text-[10px] text-muted-foreground uppercase">Voltage</span>
                  <span className="block font-mono text-amber-500">{profile.voltageOffset > 0 ? '+' : ''}{profile.voltageOffset}</span>
                </div>
                {s.hasFans ? (
                  <div className="bg-secondary/30 p-2 rounded border border-border/50 text-center">
                    <span className="block text-[10px] text-muted-foreground uppercase">Fan</span>
                    <span className="block font-mono text-blue-500">{profile.fanSpeed}%</span>
                  </div>
                ) : (
                  <div className="bg-secondary/30 p-2 rounded border border-border/50 text-center">
                    <span className="block text-[10px] text-muted-foreground uppercase">Cooling</span>
                    <span className={`block font-mono text-xs ${getCoolingColor(model?.coolingType || 'air')}`}>{getCoolingLabel(model?.coolingType || 'air')}</span>
                  </div>
                )}
              </div>
            </>
          );
        })()}
        {profile.powerCapEnabled && (
          <div className="flex items-center gap-2 text-xs text-amber-500 bg-amber-500/10 rounded p-2 border border-amber-500/20">
            <Lock className="w-3 h-3 shrink-0" />
            <span className="font-mono">Power capped at {((profile.powerCapLimit || 3500) / 1000).toFixed(2)} kW</span>
          </div>
        )}
      </CardContent>
      
      <div className="p-4 border-t border-border/50 flex gap-2">
        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className="flex-1" data-testid={`button-edit-profile-${profile.id}`}>
              <Edit className="w-4 h-4 mr-2" /> Edit
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Profile</DialogTitle>
            </DialogHeader>
            <ProfileForm profile={profile} onSuccess={() => setIsEditOpen(false)} />
          </DialogContent>
        </Dialog>
        <Button variant="destructive" size="icon" onClick={handleDelete} data-testid={`button-delete-profile-${profile.id}`}>
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </Card>
  );
}

function ProfileForm({ profile, onSuccess }: { profile?: any, onSuccess: () => void }) {
  const { toast } = useToast();
  const createMutation = useCreateProfile();
  const updateMutation = useUpdateProfile();
  const aiOptimizeMutation = useAiOptimize();
  const { data: models } = useMinerModels();

  const form = useForm<InsertProfile>({
    resolver: zodResolver(insertProfileSchema),
    defaultValues: profile || {
      name: "",
      description: "",
      modelId: undefined as any,
      targetHashrate: 300,
      targetPower: 3200,
      voltageOffset: 0,
      fanSpeed: 100,
      mhzFrequency: 250,
      thermalThreshold: 85,
      powerCapEnabled: false,
      powerCapLimit: 3500,
      autoTuneMode: "none",
      autoTuneTarget: undefined,
      isAiOptimized: false,
    }
  });

  const watchedModelId = form.watch("modelId");
  const selectedModel = useMemo(() => models?.find(m => m.id === watchedModelId), [models, watchedModelId]);
  const specs = useMemo(() => modelToSpecs(selectedModel), [selectedModel]);

  const groupedModels = useMemo(() => {
    if (!models) return {};
    const groups: Record<string, MinerModel[]> = {};
    models.forEach(m => {
      const cat = m.coolingType === "air" && m.series === "Home" ? "Home / Prosumer" : 
                  m.coolingType === "air" ? "Air-Cooled Industrial" : 
                  m.coolingType === "hydro" ? "Hydro-Cooled" : "Immersion-Cooled";
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(m);
    });
    return groups;
  }, [models]);

  const onSubmit = async (data: InsertProfile) => {
    try {
      if (profile) {
        await updateMutation.mutateAsync({ id: profile.id, ...data });
        toast({ title: "Profile updated" });
      } else {
        await createMutation.mutateAsync(data);
        toast({ title: "Profile created" });
      }
      onSuccess();
    } catch (error) {
      toast({ variant: "destructive", title: "Error", description: (error as Error).message });
    }
  };

  const handleAiOptimize = async () => {
    try {
      toast({ title: "AI Analysis in progress...", description: "Optimizing parameters based on hardware specs." });
      const result = await aiOptimizeMutation.mutateAsync({
        goal: "balanced",
        constraints: { maxPower: 3500 }
      });
      
      if (result.recommendedProfile) {
        const current = form.getValues();
        form.reset({ ...current, ...result.recommendedProfile, isAiOptimized: true });
        toast({ 
          title: "Optimization Complete", 
          description: result.reasoning,
        });
      }
    } catch (error) {
      toast({ variant: "destructive", title: "Optimization failed", description: (error as Error).message });
    }
  };

  const watchedMhz = form.watch("mhzFrequency") || 250;
  const watchedFanSpeed = form.watch("fanSpeed") || 100;
  const watchedVoltage = form.watch("voltageOffset") || 0;
  const watchedThermal = form.watch("thermalThreshold") || 85;
  const watchedPowerKw = form.watch("targetPower") || 3200;
  const watchedPowerCapEnabled = form.watch("powerCapEnabled") || false;
  const watchedPowerCapLimit = form.watch("powerCapLimit") || 3500;
  const watchedAutoTuneMode = form.watch("autoTuneMode") || "none";
  const watchedAutoTuneTarget = form.watch("autoTuneTarget");

  const isAutoTuneActive = watchedAutoTuneMode !== "none";

  const applyAutoTune = useCallback((mode: string, target: number | null | undefined) => {
    if (!mode || mode === "none" || target == null) return;
    const result = computeAutoTune(mode, target, specs);
    if (!result) return;
    const capEnabled = form.getValues("powerCapEnabled");
    const capLimit = form.getValues("powerCapLimit") || specs.maxPow;
    let power = result.targetPower;
    if (capEnabled && power > capLimit) {
      power = capLimit;
    }
    form.setValue("targetPower", power);
    form.setValue("mhzFrequency", result.mhzFrequency);
    form.setValue("targetHashrate", result.targetHashrate);
    form.setValue("thermalThreshold", result.thermalThreshold);
    form.setValue("fanSpeed", result.fanSpeed);
    form.setValue("voltageOffset", result.voltageOffset);
  }, [form, specs]);

  useEffect(() => {
    if (watchedAutoTuneMode !== "none" && watchedAutoTuneTarget != null) {
      applyAutoTune(watchedAutoTuneMode, watchedAutoTuneTarget);
    }
  }, [watchedAutoTuneMode, watchedAutoTuneTarget, applyAutoTune]);

  const getTargetLabel = (mode: string) => {
    const minHash = Math.round(specs.defHash * 0.5);
    const maxHash = Math.round(specs.defHash * 1.5);
    switch (mode) {
      case "power": return { label: "Target Power (watts)", min: specs.minPow, max: specs.maxPow, step: 10, unit: "W", format: (v: number) => `${(v/1000).toFixed(2)} kW` };
      case "hashrate": return { label: "Target Hashrate (TH/s)", min: minHash, max: maxHash, step: 1, unit: "TH/s", format: (v: number) => `${v} TH/s` };
      case "efficiency": return { label: "Target Efficiency (J/TH)", min: 10, max: 50, step: 1, unit: "J/TH", format: (v: number) => `${v} J/TH` };
      case "temperature": return { label: "Target Temperature (°C)", min: specs.minTherm, max: specs.maxTherm, step: 1, unit: "°C", format: (v: number) => `${v}°C` };
      default: return null;
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="modelId"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5" /> Miner Model
              </FormLabel>
              <FormControl>
                <Select
                  value={field.value ? String(field.value) : ""}
                  onValueChange={(val) => {
                    const id = parseInt(val);
                    field.onChange(id);
                    const m = models?.find(mm => mm.id === id);
                    if (m) {
                      form.setValue("mhzFrequency", m.defaultFrequency);
                      form.setValue("targetPower", m.defaultPower);
                      form.setValue("thermalThreshold", m.defaultThermal);
                      form.setValue("targetHashrate", m.defaultHashrate);
                      form.setValue("powerCapLimit", m.maxPower);
                      if (!m.hasFans) form.setValue("fanSpeed", 0);
                      else form.setValue("fanSpeed", 80);
                    }
                  }}
                >
                  <SelectTrigger data-testid="select-miner-model">
                    <SelectValue placeholder="Select miner model..." />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(groupedModels).map(([category, catModels]) => (
                      <div key={category}>
                        <div className="px-2 py-1.5 text-[10px] font-mono uppercase text-muted-foreground tracking-wider">{category}</div>
                        {catModels.map(m => {
                          const Icon = getCoolingIcon(m.coolingType);
                          return (
                            <SelectItem key={m.id} value={String(m.id)} data-testid={`option-model-${m.id}`}>
                              <span className="flex items-center gap-2">
                                <Icon className={`w-3.5 h-3.5 ${getCoolingColor(m.coolingType)}`} />
                                <span>{m.name}</span>
                                <span className="text-muted-foreground text-xs">{m.defaultHashrate} TH/s | {m.efficiency} J/TH</span>
                              </span>
                            </SelectItem>
                          );
                        })}
                      </div>
                    ))}
                  </SelectContent>
                </Select>
              </FormControl>
              {selectedModel && (
                <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1 flex-wrap">
                  <span className="font-mono">{selectedModel.defaultHashrate} TH/s</span>
                  <span className="font-mono">{(selectedModel.defaultPower / 1000).toFixed(1)} kW</span>
                  <span className="font-mono">{selectedModel.efficiency} J/TH</span>
                  <span className="font-mono">{selectedModel.minFrequency}-{selectedModel.maxFrequency} MHz</span>
                </div>
              )}
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Profile Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g. High Performance" data-testid="input-profile-name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Describe the use case..." className="min-h-[80px]" data-testid="input-profile-description" {...field} value={field.value || ''} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="targetHashrate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Target Hash (TH/s)</FormLabel>
                  <FormControl>
                    <Input type="number" data-testid="input-target-hashrate" {...field} onChange={e => field.onChange(parseInt(e.target.value))} value={field.value || ''} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <div className="space-y-5 p-4 rounded-xl bg-secondary/20 border border-border/50">
            <div className="flex justify-between items-center mb-2 flex-wrap gap-2">
              <h4 className="font-medium text-sm flex items-center gap-2">
                <Zap className="w-4 h-4" /> Hardware Tuning
              </h4>
              <Button 
                type="button" 
                size="sm" 
                variant="outline" 
                onClick={handleAiOptimize}
                disabled={aiOptimizeMutation.isPending || isAutoTuneActive}
                data-testid="button-ai-optimize"
              >
                <Bot className="w-3 h-3 mr-1" />
                {aiOptimizeMutation.isPending ? "Analyzing..." : "Auto-Optimize"}
              </Button>
            </div>

            <div className="rounded-lg border border-purple-500/30 bg-purple-500/5 p-3 space-y-3">
              <div className="flex items-center gap-2 mb-1">
                <Target className="w-4 h-4 text-purple-400" />
                <span className="text-sm font-medium text-purple-400">Auto-Tune Mode</span>
              </div>
              <FormField
                control={form.control}
                name="autoTuneMode"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Select
                        value={field.value || "none"}
                        onValueChange={(val) => {
                          field.onChange(val);
                          if (val === "none") {
                            form.setValue("autoTuneTarget", undefined as any);
                          } else {
                            const cfg = getTargetLabel(val);
                            if (cfg) {
                              const defaultTarget = val === "power" ? specs.defPow : 
                                val === "hashrate" ? specs.defHash : 
                                val === "efficiency" ? 28 : 
                                specs.defTherm;
                              form.setValue("autoTuneTarget", defaultTarget);
                            }
                          }
                        }}
                      >
                        <SelectTrigger data-testid="select-auto-tune-mode" className="bg-background/50">
                          <SelectValue placeholder="Select mode" />
                        </SelectTrigger>
                        <SelectContent>
                          {AUTO_TUNE_MODES.map((m) => (
                            <SelectItem key={m.value} value={m.value} data-testid={`option-autotune-${m.value}`}>
                              <span className="flex items-center gap-2">
                                <m.icon className="w-3.5 h-3.5" />
                                {m.label}
                              </span>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {isAutoTuneActive && (() => {
                const cfg = getTargetLabel(watchedAutoTuneMode);
                if (!cfg) return null;
                return (
                  <FormField
                    control={form.control}
                    name="autoTuneTarget"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex justify-between mb-2">
                          <FormLabel className="text-xs">{cfg.label}</FormLabel>
                          <span className="text-xs font-mono text-purple-400">
                            {field.value != null ? cfg.format(field.value) : "—"}
                          </span>
                        </div>
                        <FormControl>
                          <Slider
                            min={cfg.min}
                            max={cfg.max}
                            step={cfg.step}
                            value={[field.value ?? cfg.min]}
                            onValueChange={(vals) => field.onChange(vals[0])}
                            data-testid="slider-auto-tune-target"
                          />
                        </FormControl>
                        <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                          <span>{cfg.format(cfg.min)}</span>
                          <span>{cfg.format(cfg.max)}</span>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                );
              })()}

              {isAutoTuneActive && (
                <p className="text-[10px] text-muted-foreground">
                  All other parameters are auto-calculated. Switch to Manual to adjust individually.
                </p>
              )}
            </div>

            <div className={isAutoTuneActive ? "opacity-60 pointer-events-none" : ""}>
            <FormField
              control={form.control}
              name="thermalThreshold"
              render={({ field }) => (
                <FormItem>
                  <div className="flex justify-between mb-2">
                    <FormLabel className="flex items-center gap-1.5">
                      <Thermometer className="w-3.5 h-3.5 text-red-500" /> Thermal Threshold
                      {isAutoTuneActive && <span className="text-[10px] text-purple-400 ml-1">(auto)</span>}
                    </FormLabel>
                    <div className="flex items-center gap-1">
                      <Input
                        type="number"
                        min={specs.minTherm} max={specs.maxTherm} step={1}
                        value={field.value || specs.defTherm}
                        disabled={isAutoTuneActive}
                        onChange={(e) => {
                          const v = Math.min(specs.maxTherm, Math.max(specs.minTherm, parseInt(e.target.value) || specs.minTherm));
                          field.onChange(v);
                        }}
                        className={`w-16 h-7 text-xs font-mono text-right px-1 ${(field.value || specs.defTherm) >= 90 ? 'text-red-500' : (field.value || specs.defTherm) >= 75 ? 'text-amber-500' : 'text-emerald-500'}`}
                        data-testid="input-thermal-threshold"
                      />
                      <span className="text-xs text-muted-foreground">°C</span>
                    </div>
                  </div>
                  <FormControl>
                    <Slider 
                      min={specs.minTherm} max={specs.maxTherm} step={1} 
                      value={[field.value || specs.defTherm]} 
                      onValueChange={(vals) => field.onChange(vals[0])}
                      disabled={isAutoTuneActive}
                      data-testid="slider-thermal-threshold"
                    />
                  </FormControl>
                  <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                    <span>{specs.minTherm}°C</span>
                    <span>{Math.round((specs.minTherm + specs.maxTherm) / 2)}°C</span>
                    <span>{specs.maxTherm}°C</span>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="mhzFrequency"
              render={({ field }) => (
                <FormItem>
                  <div className="flex justify-between mb-2">
                    <FormLabel className="flex items-center gap-1.5">
                      <Cpu className="w-3.5 h-3.5 text-cyan-500" /> Chip Frequency
                      {isAutoTuneActive && <span className="text-[10px] text-purple-400 ml-1">(auto)</span>}
                    </FormLabel>
                    <div className="flex items-center gap-1">
                      <Input
                        type="number"
                        min={specs.minFreq} max={specs.maxFreq} step={1}
                        value={field.value || specs.defFreq}
                        disabled={isAutoTuneActive}
                        onChange={(e) => {
                          const v = Math.min(specs.maxFreq, Math.max(specs.minFreq, parseInt(e.target.value) || specs.minFreq));
                          field.onChange(v);
                        }}
                        className="w-16 h-7 text-xs font-mono text-right text-cyan-500 px-1"
                        data-testid="input-mhz-frequency"
                      />
                      <span className="text-xs text-muted-foreground">MHz</span>
                    </div>
                  </div>
                  <FormControl>
                    <Slider 
                      min={specs.minFreq} max={specs.maxFreq} step={1} 
                      value={[field.value || specs.defFreq]} 
                      onValueChange={(vals) => field.onChange(vals[0])}
                      disabled={isAutoTuneActive}
                      data-testid="slider-mhz-frequency"
                    />
                  </FormControl>
                  <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                    <span>{specs.minFreq} MHz</span>
                    <span>{Math.round((specs.minFreq + specs.maxFreq) / 2)} MHz</span>
                    <span>{specs.maxFreq} MHz</span>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="targetPower"
              render={({ field }) => {
                const wattsVal = field.value || specs.defPow;
                const kwDisplay = (wattsVal / 1000).toFixed(2);
                const effectiveMax = watchedPowerCapEnabled ? Math.min(watchedPowerCapLimit, specs.maxPow) : specs.maxPow;
                return (
                  <FormItem>
                    <div className="flex justify-between mb-2">
                      <FormLabel className="flex items-center gap-1.5">
                        <BatteryCharging className="w-3.5 h-3.5 text-emerald-500" /> Power Draw
                        {isAutoTuneActive && <span className="text-[10px] text-purple-400 ml-1">(auto)</span>}
                      </FormLabel>
                      <div className="flex items-center gap-1">
                        <Input
                          type="number"
                          min={(specs.minPow / 1000).toFixed(2)} max={(effectiveMax / 1000).toFixed(2)} step={0.01}
                          value={kwDisplay}
                          disabled={isAutoTuneActive}
                          onChange={(e) => {
                            const kw = parseFloat(e.target.value) || specs.minPow / 1000;
                            const watts = Math.min(effectiveMax, Math.max(specs.minPow, Math.round(kw * 1000 / 10) * 10));
                            field.onChange(watts);
                          }}
                          className="w-16 h-7 text-xs font-mono text-right text-emerald-500 px-1"
                          data-testid="input-power-kw"
                        />
                        <span className="text-xs text-muted-foreground">kW</span>
                      </div>
                    </div>
                    <FormControl>
                      <Slider 
                        min={specs.minPow} max={effectiveMax} step={10} 
                        value={[Math.min(wattsVal, effectiveMax)]} 
                        onValueChange={(vals) => field.onChange(vals[0])}
                        disabled={isAutoTuneActive}
                        data-testid="slider-power-kw"
                      />
                    </FormControl>
                    <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                      <span>{(specs.minPow / 1000).toFixed(2)} kW</span>
                      <span>{(effectiveMax / 1000).toFixed(2)} kW{watchedPowerCapEnabled ? ' (cap)' : ''}</span>
                    </div>
                    <FormMessage />
                  </FormItem>
                );
              }}
            />

            <div className="rounded-lg border border-border/50 p-3 space-y-3 bg-secondary/10">
              <FormField
                control={form.control}
                name="powerCapEnabled"
                render={({ field }) => (
                  <FormItem className="flex items-center gap-3">
                    <FormControl>
                      <Checkbox
                        checked={field.value || false}
                        onCheckedChange={(checked) => {
                          field.onChange(!!checked);
                          if (checked) {
                            const currentPower = form.getValues("targetPower") || specs.defPow;
                            const capLimit = form.getValues("powerCapLimit") || specs.maxPow;
                            if (currentPower > capLimit) {
                              form.setValue("targetPower", capLimit);
                            }
                          }
                        }}
                        data-testid="checkbox-power-cap"
                      />
                    </FormControl>
                    <FormLabel className="flex items-center gap-1.5 cursor-pointer !mt-0">
                      <Lock className="w-3.5 h-3.5 text-amber-500" /> Enable Power Cap
                    </FormLabel>
                  </FormItem>
                )}
              />
              {watchedPowerCapEnabled && (
                <FormField
                  control={form.control}
                  name="powerCapLimit"
                  render={({ field }) => {
                    const capWatts = field.value || Math.round((specs.minPow + specs.maxPow) / 2);
                    const capKwDisplay = (capWatts / 1000).toFixed(2);
                    return (
                      <FormItem>
                        <div className="flex justify-between mb-2">
                          <FormLabel className="text-xs text-muted-foreground">Max Power Limit</FormLabel>
                          <div className="flex items-center gap-1">
                            <Input
                              type="number"
                              min={(specs.minPow / 1000).toFixed(2)} max={(specs.maxPow / 1000).toFixed(2)} step={0.01}
                              value={capKwDisplay}
                              onChange={(e) => {
                                const kw = parseFloat(e.target.value) || specs.minPow / 1000;
                                const watts = Math.min(specs.maxPow, Math.max(specs.minPow, Math.round(kw * 1000 / 10) * 10));
                                field.onChange(watts);
                                const currentPower = form.getValues("targetPower") || specs.defPow;
                                if (currentPower > watts) {
                                  form.setValue("targetPower", watts);
                                }
                              }}
                              className="w-16 h-7 text-xs font-mono text-right text-amber-500 px-1"
                              data-testid="input-power-cap-limit"
                            />
                            <span className="text-xs text-muted-foreground">kW</span>
                          </div>
                        </div>
                        <FormControl>
                          <Slider 
                            min={specs.minPow} max={specs.maxPow} step={10} 
                            value={[capWatts]} 
                            onValueChange={(vals) => {
                              field.onChange(vals[0]);
                              const currentPower = form.getValues("targetPower") || specs.defPow;
                              if (currentPower > vals[0]) {
                                form.setValue("targetPower", vals[0]);
                              }
                            }}
                            data-testid="slider-power-cap-limit"
                          />
                        </FormControl>
                        <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                          <span>{(specs.minPow / 1000).toFixed(2)} kW</span>
                          <span>{(Math.round((specs.minPow + specs.maxPow) / 2) / 1000).toFixed(2)} kW</span>
                          <span>{(specs.maxPow / 1000).toFixed(2)} kW</span>
                        </div>
                        <FormMessage />
                      </FormItem>
                    );
                  }}
                />
              )}
            </div>
            
            {specs.hasFans ? (
            <FormField
              control={form.control}
              name="fanSpeed"
              render={({ field }) => (
                <FormItem>
                  <div className="flex justify-between mb-2">
                    <FormLabel className="flex items-center gap-1.5">
                      <Wind className="w-3.5 h-3.5 text-blue-500" /> Fan Speed
                      {isAutoTuneActive && <span className="text-[10px] text-purple-400 ml-1">(auto)</span>}
                    </FormLabel>
                    <div className="flex items-center gap-1">
                      <Input
                        type="number"
                        min={0} max={100} step={1}
                        value={field.value ?? 100}
                        disabled={isAutoTuneActive}
                        onChange={(e) => {
                          const v = Math.min(100, Math.max(0, parseInt(e.target.value) || 0));
                          field.onChange(v);
                        }}
                        className="w-16 h-7 text-xs font-mono text-right text-blue-500 px-1"
                        data-testid="input-fan-speed"
                      />
                      <span className="text-xs text-muted-foreground">%</span>
                    </div>
                  </div>
                  <FormControl>
                    <Slider 
                      min={0} max={100} step={5} 
                      value={[field.value || 0]} 
                      onValueChange={(vals) => field.onChange(vals[0])}
                      disabled={isAutoTuneActive}
                      data-testid="slider-fan-speed"
                    />
                  </FormControl>
                  <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                    <span>0%</span>
                    <span>50%</span>
                    <span>100%</span>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            ) : (
              <div className="rounded-lg border border-border/50 p-3 bg-secondary/10">
                <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                  {selectedModel?.coolingType === "immersion" ? (
                    <><Waves className="w-3.5 h-3.5 text-purple-400" /> Immersion-cooled: No fan control</>
                  ) : (
                    <><Droplets className="w-3.5 h-3.5 text-blue-400" /> Hydro-cooled: No fan control</>
                  )}
                </p>
              </div>
            )}

            <FormField
              control={form.control}
              name="voltageOffset"
              render={({ field }) => (
                <FormItem>
                  <div className="flex justify-between mb-2">
                    <FormLabel className="flex items-center gap-1.5">
                      Voltage Offset
                      {isAutoTuneActive && <span className="text-[10px] text-purple-400 ml-1">(auto)</span>}
                    </FormLabel>
                    <div className="flex items-center gap-1">
                      <Input
                        type="number"
                        min={specs.minVolt} max={specs.maxVolt} step={1}
                        value={field.value ?? 0}
                        disabled={isAutoTuneActive}
                        onChange={(e) => {
                          const v = Math.min(specs.maxVolt, Math.max(specs.minVolt, parseInt(e.target.value) || 0));
                          field.onChange(v);
                        }}
                        className="w-16 h-7 text-xs font-mono text-right text-amber-500 px-1"
                        data-testid="input-voltage-offset"
                      />
                    </div>
                  </div>
                  <FormControl>
                    <Slider 
                      min={specs.minVolt} max={specs.maxVolt} step={1} 
                      value={[field.value || 0]} 
                      onValueChange={(vals) => field.onChange(vals[0])}
                      disabled={isAutoTuneActive}
                      data-testid="slider-voltage-offset"
                    />
                  </FormControl>
                  <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                    <span>{specs.minVolt} (Low Power)</span>
                    <span>0</span>
                    <span>+{specs.maxVolt} (High Power)</span>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t border-border/50">
          <Button type="button" variant="ghost" onClick={onSuccess} data-testid="button-cancel">Cancel</Button>
          <Button type="submit" data-testid="button-submit-profile">
            {profile ? "Save Profile" : "Create Profile"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
