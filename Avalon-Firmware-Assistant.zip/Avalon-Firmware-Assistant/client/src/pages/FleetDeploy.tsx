import { useState, useCallback, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useProfiles } from "@/hooks/use-profiles";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Building2, Warehouse, Server, HardDrive, Layers,
  ChevronRight, ChevronDown, Send, Loader2,
  CheckCircle2, XCircle, Target, AlertTriangle
} from "lucide-react";
import type { Profile } from "@shared/schema";

interface ShelfNode {
  id: number;
  name: string;
  rackId: number;
  minerCount: number;
}

interface RackNode {
  id: number;
  name: string;
  areaId: number;
  shelves: ShelfNode[];
  minerCount: number;
}

interface AreaNode {
  id: number;
  name: string;
  siteId: number;
  racks: RackNode[];
  minerCount: number;
}

interface SiteNode {
  id: number;
  name: string;
  location: string | null;
  areas: AreaNode[];
  minerCount: number;
}

type SelectionState = "none" | "some" | "all";

export default function FleetDeploy() {
  const { data: profiles, isLoading: profilesLoading } = useProfiles();
  const { toast } = useToast();

  const { data: tree, isLoading: treeLoading } = useQuery<SiteNode[]>({
    queryKey: ["/api/hierarchy/tree"],
  });

  const [selectedProfileId, setSelectedProfileId] = useState<string>("");
  const [isDeploying, setIsDeploying] = useState(false);
  const [deployResults, setDeployResults] = useState<{ ip: string; success: boolean; message: string }[] | null>(null);

  const [selectedSiteIds, setSelectedSiteIds] = useState<Set<number>>(new Set());
  const [selectedAreaIds, setSelectedAreaIds] = useState<Set<number>>(new Set());
  const [selectedRackIds, setSelectedRackIds] = useState<Set<number>>(new Set());
  const [selectedShelfIds, setSelectedShelfIds] = useState<Set<number>>(new Set());

  const [expandedSites, setExpandedSites] = useState<Set<number>>(new Set());
  const [expandedAreas, setExpandedAreas] = useState<Set<number>>(new Set());
  const [expandedRacks, setExpandedRacks] = useState<Set<number>>(new Set());

  const selectedProfile = profiles?.find(p => p.id === Number(selectedProfileId));

  const toggleExpand = useCallback((set: Set<number>, id: number, setter: React.Dispatch<React.SetStateAction<Set<number>>>) => {
    setter(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const getAllShelfIdsInRack = useCallback((rack: RackNode) => rack.shelves.map(s => s.id), []);
  const getAllShelfIdsInArea = useCallback((area: AreaNode) => area.racks.flatMap(r => r.shelves.map(s => s.id)), []);
  const getAllShelfIdsInSite = useCallback((site: SiteNode) => site.areas.flatMap(a => a.racks.flatMap(r => r.shelves.map(s => s.id))), []);
  const getAllRackIdsInArea = useCallback((area: AreaNode) => area.racks.map(r => r.id), []);
  const getAllRackIdsInSite = useCallback((site: SiteNode) => site.areas.flatMap(a => a.racks.map(r => r.id)), []);
  const getAllAreaIdsInSite = useCallback((site: SiteNode) => site.areas.map(a => a.id), []);

  const toggleShelf = useCallback((shelfId: number) => {
    setSelectedShelfIds(prev => {
      const next = new Set(prev);
      if (next.has(shelfId)) next.delete(shelfId);
      else next.add(shelfId);
      return next;
    });
  }, []);

  const toggleRack = useCallback((rack: RackNode) => {
    const shelfIds = getAllShelfIdsInRack(rack);
    const allSelected = shelfIds.every(id => selectedShelfIds.has(id));

    setSelectedShelfIds(prev => {
      const next = new Set(prev);
      shelfIds.forEach(id => allSelected ? next.delete(id) : next.add(id));
      return next;
    });
    setSelectedRackIds(prev => {
      const next = new Set(prev);
      if (allSelected) next.delete(rack.id);
      else next.add(rack.id);
      return next;
    });
  }, [selectedShelfIds, getAllShelfIdsInRack]);

  const toggleArea = useCallback((area: AreaNode) => {
    const shelfIds = getAllShelfIdsInArea(area);
    const rackIds = getAllRackIdsInArea(area);
    const allSelected = shelfIds.every(id => selectedShelfIds.has(id));

    setSelectedShelfIds(prev => {
      const next = new Set(prev);
      shelfIds.forEach(id => allSelected ? next.delete(id) : next.add(id));
      return next;
    });
    setSelectedRackIds(prev => {
      const next = new Set(prev);
      rackIds.forEach(id => allSelected ? next.delete(id) : next.add(id));
      return next;
    });
    setSelectedAreaIds(prev => {
      const next = new Set(prev);
      if (allSelected) next.delete(area.id);
      else next.add(area.id);
      return next;
    });
  }, [selectedShelfIds, getAllShelfIdsInArea, getAllRackIdsInArea]);

  const toggleSite = useCallback((site: SiteNode) => {
    const shelfIds = getAllShelfIdsInSite(site);
    const rackIds = getAllRackIdsInSite(site);
    const areaIds = getAllAreaIdsInSite(site);
    const allSelected = shelfIds.every(id => selectedShelfIds.has(id));

    setSelectedShelfIds(prev => {
      const next = new Set(prev);
      shelfIds.forEach(id => allSelected ? next.delete(id) : next.add(id));
      return next;
    });
    setSelectedRackIds(prev => {
      const next = new Set(prev);
      rackIds.forEach(id => allSelected ? next.delete(id) : next.add(id));
      return next;
    });
    setSelectedAreaIds(prev => {
      const next = new Set(prev);
      areaIds.forEach(id => allSelected ? next.delete(id) : next.add(id));
      return next;
    });
    setSelectedSiteIds(prev => {
      const next = new Set(prev);
      if (allSelected) next.delete(site.id);
      else next.add(site.id);
      return next;
    });
  }, [selectedShelfIds, getAllShelfIdsInSite, getAllRackIdsInSite, getAllAreaIdsInSite]);

  const selectAll = useCallback(() => {
    if (!tree) return;
    setSelectedShelfIds(new Set(tree.flatMap(s => s.areas.flatMap(a => a.racks.flatMap(r => r.shelves.map(sh => sh.id))))));
    setSelectedRackIds(new Set(tree.flatMap(s => s.areas.flatMap(a => a.racks.map(r => r.id)))));
    setSelectedAreaIds(new Set(tree.flatMap(s => s.areas.map(a => a.id))));
    setSelectedSiteIds(new Set(tree.map(s => s.id)));
  }, [tree]);

  const clearAll = useCallback(() => {
    setSelectedShelfIds(new Set());
    setSelectedRackIds(new Set());
    setSelectedAreaIds(new Set());
    setSelectedSiteIds(new Set());
  }, []);

  const getShelfState = useCallback((shelfId: number): SelectionState => {
    return selectedShelfIds.has(shelfId) ? "all" : "none";
  }, [selectedShelfIds]);

  const getRackState = useCallback((rack: RackNode): SelectionState => {
    if (rack.shelves.length === 0) return "none";
    const selectedCount = rack.shelves.filter(s => selectedShelfIds.has(s.id)).length;
    if (selectedCount === 0) return "none";
    if (selectedCount === rack.shelves.length) return "all";
    return "some";
  }, [selectedShelfIds]);

  const getAreaState = useCallback((area: AreaNode): SelectionState => {
    const allShelves = area.racks.flatMap(r => r.shelves);
    if (allShelves.length === 0) return "none";
    const selectedCount = allShelves.filter(s => selectedShelfIds.has(s.id)).length;
    if (selectedCount === 0) return "none";
    if (selectedCount === allShelves.length) return "all";
    return "some";
  }, [selectedShelfIds]);

  const getSiteState = useCallback((site: SiteNode): SelectionState => {
    const allShelves = site.areas.flatMap(a => a.racks.flatMap(r => r.shelves));
    if (allShelves.length === 0) return "none";
    const selectedCount = allShelves.filter(s => selectedShelfIds.has(s.id)).length;
    if (selectedCount === 0) return "none";
    if (selectedCount === allShelves.length) return "all";
    return "some";
  }, [selectedShelfIds]);

  const totalSelectedMiners = useMemo(() => {
    if (!tree) return 0;
    let count = 0;
    tree.forEach(site => {
      site.areas.forEach(area => {
        area.racks.forEach(rack => {
          rack.shelves.forEach(shelf => {
            if (selectedShelfIds.has(shelf.id)) {
              count += shelf.minerCount;
            }
          });
        });
      });
    });
    return count;
  }, [tree, selectedShelfIds]);

  const totalMiners = useMemo(() => {
    if (!tree) return 0;
    return tree.reduce((sum, s) => sum + s.minerCount, 0);
  }, [tree]);

  const deployToFleet = async () => {
    if (!selectedProfileId) {
      toast({ variant: "destructive", title: "No profile selected", description: "Choose a tuning profile to deploy." });
      return;
    }
    if (selectedShelfIds.size === 0) {
      toast({ variant: "destructive", title: "No miners selected", description: "Select at least one location to deploy to." });
      return;
    }

    setIsDeploying(true);
    setDeployResults(null);

    try {
      const response = await apiRequest("POST", "/api/fleet/deploy", {
        profileId: Number(selectedProfileId),
        shelfIds: Array.from(selectedShelfIds),
      });
      const data = await response.json();

      setDeployResults(data.results || []);

      const successCount = data.results?.filter((r: any) => r.success).length || 0;
      const failCount = data.results?.filter((r: any) => !r.success).length || 0;

      toast({
        title: "Deployment Complete",
        description: `${successCount} succeeded, ${failCount} failed out of ${data.totalMiners} miners.`,
      });
    } catch (error) {
      toast({ variant: "destructive", title: "Deployment failed", description: (error as Error).message });
    } finally {
      setIsDeploying(false);
    }
  };

  const checkboxClass = (state: SelectionState) => {
    if (state === "some") return "data-[state=checked]:bg-cyan-500/50";
    return "";
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-start flex-wrap gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight" data-testid="text-fleet-deploy-title">Fleet Deploy</h2>
          <p className="text-muted-foreground">
            Select locations from your site hierarchy and push tuning configs to all miners at once.
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {totalSelectedMiners > 0 && (
            <Badge variant="secondary" data-testid="badge-selected-count">
              {totalSelectedMiners.toLocaleString()} miner{totalSelectedMiners !== 1 ? 's' : ''} selected
            </Badge>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Target className="w-4 h-4" /> Deploy Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Tuning Profile</Label>
                <Select value={selectedProfileId} onValueChange={setSelectedProfileId}>
                  <SelectTrigger data-testid="select-deploy-profile">
                    <SelectValue placeholder="Select a profile..." />
                  </SelectTrigger>
                  <SelectContent>
                    {profiles?.map(p => (
                      <SelectItem key={p.id} value={String(p.id)} data-testid={`option-profile-${p.id}`}>
                        {p.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedProfile && (
                <div className="rounded-lg bg-secondary/30 border border-border/50 p-3 space-y-1.5">
                  <p className="text-xs font-mono text-muted-foreground uppercase tracking-wider">Profile Summary</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div><span className="text-muted-foreground">Freq:</span> <span className="font-mono text-cyan-500">{selectedProfile.mhzFrequency} MHz</span></div>
                    <div><span className="text-muted-foreground">Power:</span> <span className="font-mono text-emerald-500">{((selectedProfile.targetPower || 3200) / 1000).toFixed(2)} kW</span></div>
                    <div><span className="text-muted-foreground">Thermal:</span> <span className="font-mono text-red-500">{selectedProfile.thermalThreshold}°C</span></div>
                    <div><span className="text-muted-foreground">Fan:</span> <span className="font-mono text-blue-500">{selectedProfile.fanSpeed}%</span></div>
                    <div><span className="text-muted-foreground">Voltage:</span> <span className="font-mono text-amber-500">{(selectedProfile.voltageOffset || 0) > 0 ? '+' : ''}{selectedProfile.voltageOffset || 0}</span></div>
                    {selectedProfile.autoTuneMode && selectedProfile.autoTuneMode !== "none" && (
                      <div><span className="text-muted-foreground">Mode:</span> <span className="font-mono text-purple-400">{selectedProfile.autoTuneMode}</span></div>
                    )}
                  </div>
                </div>
              )}

              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between gap-2">
                  <Label className="text-sm">Selection</Label>
                  <div className="flex gap-1">
                    <Button type="button" variant="ghost" size="sm" onClick={selectAll} data-testid="button-select-all">
                      Select All
                    </Button>
                    <Button type="button" variant="ghost" size="sm" onClick={clearAll} data-testid="button-clear-all">
                      Clear
                    </Button>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">
                  {totalSelectedMiners.toLocaleString()} of {totalMiners.toLocaleString()} miners selected
                </div>
              </div>

              <Button
                type="button"
                className="w-full"
                onClick={deployToFleet}
                disabled={isDeploying || !selectedProfileId || selectedShelfIds.size === 0}
                data-testid="button-deploy"
              >
                {isDeploying ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Deploying to {totalSelectedMiners.toLocaleString()} miners...</>
                ) : (
                  <><Send className="w-4 h-4 mr-2" /> Deploy to {totalSelectedMiners.toLocaleString()} Miner{totalSelectedMiners !== 1 ? 's' : ''}</>
                )}
              </Button>
            </CardContent>
          </Card>

          {deployResults && deployResults.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" /> Deployment Results
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-1 max-h-[300px] overflow-y-auto">
                  {deployResults.slice(0, 100).map((r, idx) => (
                    <div key={idx} className="flex items-center justify-between gap-2 py-1 text-xs" data-testid={`deploy-result-${idx}`}>
                      <span className="font-mono truncate">{r.ip}</span>
                      <div className="flex items-center gap-1 shrink-0">
                        {r.success ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                        ) : (
                          <XCircle className="w-3 h-3 text-red-500" />
                        )}
                        <span className={r.success ? "text-emerald-500" : "text-red-400"}>
                          {r.success ? "OK" : r.message}
                        </span>
                      </div>
                    </div>
                  ))}
                  {deployResults.length > 100 && (
                    <p className="text-xs text-muted-foreground pt-2">...and {deployResults.length - 100} more</p>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
              <CardTitle className="text-base flex items-center gap-2">
                <Building2 className="w-4 h-4" /> Site Hierarchy
              </CardTitle>
              <span className="text-xs text-muted-foreground font-mono">
                {tree?.length ?? 0} site{(tree?.length ?? 0) !== 1 ? 's' : ''}
              </span>
            </CardHeader>
            <CardContent>
              {treeLoading ? (
                <div className="flex items-center justify-center p-12">
                  <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                </div>
              ) : !tree || tree.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-12 border border-dashed border-border rounded-xl">
                  <Building2 className="w-12 h-12 text-muted-foreground mb-4 opacity-20" />
                  <h3 className="text-lg font-medium">No Sites Configured</h3>
                  <p className="text-muted-foreground text-sm max-w-sm text-center mt-2">
                    Create sites, areas, racks, and shelves to organize your fleet hierarchy.
                  </p>
                </div>
              ) : (
                <div className="space-y-1" data-testid="hierarchy-tree">
                  {tree.map(site => (
                    <SiteRow
                      key={site.id}
                      site={site}
                      expanded={expandedSites.has(site.id)}
                      onToggleExpand={() => toggleExpand(expandedSites, site.id, setExpandedSites)}
                      onToggleSelect={() => toggleSite(site)}
                      selectionState={getSiteState(site)}
                      expandedAreas={expandedAreas}
                      expandedRacks={expandedRacks}
                      onToggleExpandArea={(id) => toggleExpand(expandedAreas, id, setExpandedAreas)}
                      onToggleExpandRack={(id) => toggleExpand(expandedRacks, id, setExpandedRacks)}
                      onToggleSelectArea={toggleArea}
                      onToggleSelectRack={toggleRack}
                      onToggleSelectShelf={toggleShelf}
                      getAreaState={getAreaState}
                      getRackState={getRackState}
                      getShelfState={getShelfState}
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function TreeCheckbox({ state, onToggle, testId }: { state: SelectionState; onToggle: () => void; testId?: string }) {
  return (
    <div onClick={(e) => e.stopPropagation()}>
      <Checkbox
        checked={state === "all" ? true : state === "some" ? "indeterminate" : false}
        onCheckedChange={onToggle}
        data-testid={testId}
        className="shrink-0"
      />
    </div>
  );
}

function SiteRow({
  site,
  expanded,
  onToggleExpand,
  onToggleSelect,
  selectionState,
  expandedAreas,
  expandedRacks,
  onToggleExpandArea,
  onToggleExpandRack,
  onToggleSelectArea,
  onToggleSelectRack,
  onToggleSelectShelf,
  getAreaState,
  getRackState,
  getShelfState,
}: {
  site: SiteNode;
  expanded: boolean;
  onToggleExpand: () => void;
  onToggleSelect: () => void;
  selectionState: SelectionState;
  expandedAreas: Set<number>;
  expandedRacks: Set<number>;
  onToggleExpandArea: (id: number) => void;
  onToggleExpandRack: (id: number) => void;
  onToggleSelectArea: (area: AreaNode) => void;
  onToggleSelectRack: (rack: RackNode) => void;
  onToggleSelectShelf: (shelfId: number) => void;
  getAreaState: (area: AreaNode) => SelectionState;
  getRackState: (rack: RackNode) => SelectionState;
  getShelfState: (shelfId: number) => SelectionState;
}) {
  return (
    <div data-testid={`site-node-${site.id}`}>
      <div
        className="flex items-center gap-2 p-2 rounded-lg hover-elevate cursor-pointer"
        onClick={onToggleExpand}
      >
        <TreeCheckbox state={selectionState} onToggle={onToggleSelect} testId={`checkbox-site-${site.id}`} />
        <button type="button" className="shrink-0" onClick={(e) => { e.stopPropagation(); onToggleExpand(); }}>
          {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </button>
        <Building2 className="w-4 h-4 text-cyan-500 shrink-0" />
        <span className="font-medium text-sm truncate">{site.name}</span>
        {site.location && <span className="text-xs text-muted-foreground truncate hidden sm:inline">({site.location})</span>}
        <Badge variant="secondary" className="ml-auto shrink-0 text-xs">
          {site.minerCount.toLocaleString()} miners
        </Badge>
      </div>

      {expanded && (
        <div className="ml-6 border-l border-border/40 pl-2 space-y-0.5">
          {site.areas.map(area => (
            <AreaRow
              key={area.id}
              area={area}
              expanded={expandedAreas.has(area.id)}
              onToggleExpand={() => onToggleExpandArea(area.id)}
              onToggleSelect={() => onToggleSelectArea(area)}
              selectionState={getAreaState(area)}
              expandedRacks={expandedRacks}
              onToggleExpandRack={onToggleExpandRack}
              onToggleSelectRack={onToggleSelectRack}
              onToggleSelectShelf={onToggleSelectShelf}
              getRackState={getRackState}
              getShelfState={getShelfState}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function AreaRow({
  area,
  expanded,
  onToggleExpand,
  onToggleSelect,
  selectionState,
  expandedRacks,
  onToggleExpandRack,
  onToggleSelectRack,
  onToggleSelectShelf,
  getRackState,
  getShelfState,
}: {
  area: AreaNode;
  expanded: boolean;
  onToggleExpand: () => void;
  onToggleSelect: () => void;
  selectionState: SelectionState;
  expandedRacks: Set<number>;
  onToggleExpandRack: (id: number) => void;
  onToggleSelectRack: (rack: RackNode) => void;
  onToggleSelectShelf: (shelfId: number) => void;
  getRackState: (rack: RackNode) => SelectionState;
  getShelfState: (shelfId: number) => SelectionState;
}) {
  return (
    <div data-testid={`area-node-${area.id}`}>
      <div
        className="flex items-center gap-2 p-2 rounded-lg hover-elevate cursor-pointer"
        onClick={onToggleExpand}
      >
        <TreeCheckbox state={selectionState} onToggle={onToggleSelect} testId={`checkbox-area-${area.id}`} />
        <button type="button" className="shrink-0" onClick={(e) => { e.stopPropagation(); onToggleExpand(); }}>
          {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </button>
        <Warehouse className="w-4 h-4 text-amber-500 shrink-0" />
        <span className="text-sm truncate">{area.name}</span>
        <Badge variant="secondary" className="ml-auto shrink-0 text-xs">
          {area.minerCount.toLocaleString()}
        </Badge>
      </div>

      {expanded && (
        <div className="ml-6 border-l border-border/40 pl-2 space-y-0.5">
          {area.racks.map(rack => (
            <RackRow
              key={rack.id}
              rack={rack}
              expanded={expandedRacks.has(rack.id)}
              onToggleExpand={() => onToggleExpandRack(rack.id)}
              onToggleSelect={() => onToggleSelectRack(rack)}
              selectionState={getRackState(rack)}
              onToggleSelectShelf={onToggleSelectShelf}
              getShelfState={getShelfState}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function RackRow({
  rack,
  expanded,
  onToggleExpand,
  onToggleSelect,
  selectionState,
  onToggleSelectShelf,
  getShelfState,
}: {
  rack: RackNode;
  expanded: boolean;
  onToggleExpand: () => void;
  onToggleSelect: () => void;
  selectionState: SelectionState;
  onToggleSelectShelf: (shelfId: number) => void;
  getShelfState: (shelfId: number) => SelectionState;
}) {
  return (
    <div data-testid={`rack-node-${rack.id}`}>
      <div
        className="flex items-center gap-2 p-2 rounded-lg hover-elevate cursor-pointer"
        onClick={onToggleExpand}
      >
        <TreeCheckbox state={selectionState} onToggle={onToggleSelect} testId={`checkbox-rack-${rack.id}`} />
        <button type="button" className="shrink-0" onClick={(e) => { e.stopPropagation(); onToggleExpand(); }}>
          {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
        </button>
        <Server className="w-4 h-4 text-emerald-500 shrink-0" />
        <span className="text-sm truncate">{rack.name}</span>
        <Badge variant="secondary" className="ml-auto shrink-0 text-xs">
          {rack.minerCount.toLocaleString()}
        </Badge>
      </div>

      {expanded && (
        <div className="ml-6 border-l border-border/40 pl-2 space-y-0.5">
          {rack.shelves.map(shelf => (
            <ShelfRow
              key={shelf.id}
              shelf={shelf}
              selected={getShelfState(shelf.id) === "all"}
              onToggle={() => onToggleSelectShelf(shelf.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function ShelfRow({
  shelf,
  selected,
  onToggle,
}: {
  shelf: ShelfNode;
  selected: boolean;
  onToggle: () => void;
}) {
  return (
    <div
      className="flex items-center gap-2 p-2 rounded-lg hover-elevate cursor-pointer"
      onClick={onToggle}
      data-testid={`shelf-node-${shelf.id}`}
    >
      <div onClick={(e) => e.stopPropagation()}>
        <Checkbox
          checked={selected}
          onCheckedChange={onToggle}
          data-testid={`checkbox-shelf-${shelf.id}`}
          className="shrink-0"
        />
      </div>
      <Layers className="w-4 h-4 text-purple-400 shrink-0" />
      <span className="text-sm truncate">{shelf.name}</span>
      <Badge variant="secondary" className="ml-auto shrink-0 text-xs">
        {shelf.minerCount.toLocaleString()}
      </Badge>
    </div>
  );
}
