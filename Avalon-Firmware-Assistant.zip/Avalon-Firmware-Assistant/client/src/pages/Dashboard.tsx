import { useMiners } from "@/hooks/use-miners";
import { useBuildJobs } from "@/hooks/use-builds";
import { Activity, Zap, Server, Thermometer, Cpu } from "lucide-react";
import { 
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
  ScatterChart, Scatter, ZAxis, Legend, Line, ComposedChart, Bar
} from "recharts";
import { StatusBadge } from "@/components/StatusBadge";
import { formatDistanceToNow } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const mockChartData = [
  { time: "00:00", hashrate: 320 },
  { time: "04:00", hashrate: 345 },
  { time: "08:00", hashrate: 310 },
  { time: "12:00", hashrate: 380 },
  { time: "16:00", hashrate: 360 },
  { time: "20:00", hashrate: 395 },
  { time: "24:00", hashrate: 385 },
];

const powerHeatCurve = [
  { power: 2200, temp: 42, freq: 200, label: "200 MHz" },
  { power: 2500, temp: 48, freq: 300, label: "300 MHz" },
  { power: 2800, temp: 55, freq: 350, label: "350 MHz" },
  { power: 3000, temp: 62, freq: 400, label: "400 MHz" },
  { power: 3200, temp: 68, freq: 450, label: "450 MHz (Default)" },
  { power: 3350, temp: 73, freq: 500, label: "500 MHz" },
  { power: 3500, temp: 78, freq: 550, label: "550 MHz" },
  { power: 3700, temp: 83, freq: 600, label: "600 MHz" },
  { power: 3800, temp: 85, freq: 650, label: "650 MHz" },
  { power: 4000, temp: 92, freq: 700, label: "700 MHz" },
  { power: 4200, temp: 98, freq: 750, label: "750 MHz" },
  { power: 4400, temp: 105, freq: 800, label: "800 MHz (Max)" },
];

const CustomPowerHeatTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-card border border-border rounded-md p-3 shadow-lg">
        <p className="text-sm font-medium text-foreground mb-1">{data.label}</p>
        <div className="space-y-1 text-xs">
          <p className="text-amber-500">Power: {data.power}W</p>
          <p className="text-red-400">Chip Temp: {data.temp}°C</p>
          <p className="text-cyan-400">Frequency: {data.freq} MHz</p>
        </div>
        {data.temp >= 90 && (
          <p className="text-[10px] text-red-500 mt-1 border-t border-border pt-1">
            Warning: Thermal throttling likely
          </p>
        )}
      </div>
    );
  }
  return null;
};

export default function Dashboard() {
  const { data: miners } = useMiners();
  const { data: jobs } = useBuildJobs();

  const totalHashrate = miners?.reduce((acc, m) => acc + (m.currentHashrate || 0), 0) || 0;
  const activeMiners = miners?.filter(m => m.status === 'mining').length || 0;
  const avgTemp = miners?.length 
    ? Math.round(miners.reduce((acc, m) => acc + (m.currentTemp || 0), 0) / miners.length) 
    : 0;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-3xl font-bold tracking-tight mb-2" data-testid="text-dashboard-title">Network Overview</h2>
        <p className="text-muted-foreground">Real-time monitoring of Avalon A16 fleet performance.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard 
          title="Total Hashrate" 
          value={`${totalHashrate} TH/s`} 
          icon={Activity} 
          trend="+5.2%" 
          color="text-primary"
        />
        <StatsCard 
          title="Active Miners" 
          value={`${activeMiners}/${miners?.length || 0}`} 
          icon={Server} 
          trend="Stable" 
          color="text-blue-500"
        />
        <StatsCard 
          title="Avg Temperature" 
          value={`${avgTemp}°C`} 
          icon={Thermometer} 
          trend="-2°C" 
          color="text-amber-500"
        />
        <StatsCard 
          title="Power Efficiency" 
          value="42 J/TH" 
          icon={Zap} 
          trend="Optimized" 
          color="text-emerald-500"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card data-testid="card-hashrate-chart">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Hashrate History (24h)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={mockChartData}>
                  <defs>
                    <linearGradient id="colorHash" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis 
                    dataKey="time" 
                    stroke="hsl(var(--muted-foreground))" 
                    tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 11}} 
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))" 
                    tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 11}} 
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(value) => `${value} T`}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px', color: 'hsl(var(--foreground))' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="hashrate" 
                    stroke="#10b981" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorHash)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="card-power-heat-chart">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Cpu className="w-5 h-5 text-cyan-500" />
              Power vs Chip Heat Curve
            </CardTitle>
            <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Avalon A16</span>
          </CardHeader>
          <CardContent>
            <div className="h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={powerHeatCurve}>
                  <defs>
                    <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis 
                    dataKey="power" 
                    stroke="hsl(var(--muted-foreground))" 
                    tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 11}} 
                    axisLine={false}
                    tickLine={false}
                    label={{ value: "Power (Watts)", position: "insideBottom", offset: -5, fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
                  />
                  <YAxis 
                    yAxisId="temp"
                    stroke="hsl(var(--muted-foreground))" 
                    tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 11}} 
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(value) => `${value}°C`}
                    domain={[30, 110]}
                    label={{ value: "Temperature (°C)", angle: -90, position: "insideLeft", fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
                  />
                  <YAxis 
                    yAxisId="freq"
                    orientation="right"
                    stroke="hsl(var(--muted-foreground))" 
                    tick={{fill: 'hsl(var(--muted-foreground))', fontSize: 11}} 
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(value) => `${value}`}
                    domain={[0, 900]}
                    label={{ value: "MHz", angle: 90, position: "insideRight", fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
                  />
                  <Tooltip content={<CustomPowerHeatTooltip />} />
                  <Area
                    yAxisId="temp"
                    type="monotone"
                    dataKey="temp"
                    stroke="#ef4444"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorTemp)"
                    name="Temperature"
                    dot={{ fill: '#ef4444', r: 3, strokeWidth: 0 }}
                    activeDot={{ r: 5, stroke: '#ef4444', strokeWidth: 2, fill: 'hsl(var(--card))' }}
                  />
                  <Line
                    yAxisId="freq"
                    type="monotone"
                    dataKey="freq"
                    stroke="#22d3ee"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={{ fill: '#22d3ee', r: 3, strokeWidth: 0 }}
                    name="Frequency"
                  />
                  {/* Thermal throttle threshold line */}
                  <Line
                    yAxisId="temp"
                    type="monotone"
                    dataKey={() => 90}
                    stroke="#f59e0b"
                    strokeWidth={1}
                    strokeDasharray="8 4"
                    dot={false}
                    name="Throttle Threshold"
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
            <div className="flex items-center gap-4 mt-3 text-[10px] text-muted-foreground flex-wrap">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-0.5 bg-red-500 rounded" />
                <span>Chip Temp</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-0.5 bg-cyan-400 rounded" style={{ borderTop: '1px dashed' }} />
                <span>Frequency</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-0.5 bg-amber-500 rounded" style={{ borderTop: '1px dashed' }} />
                <span>Throttle Limit (90°C)</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card data-testid="card-recent-jobs">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-lg">Recent Build Jobs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {jobs?.slice(0, 5).map((job) => (
                <div key={job.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/30 border border-border/50 flex-wrap gap-2" data-testid={`row-job-${job.id}`}>
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-primary" />
                    <div>
                      <div className="text-sm font-medium">Profile Update #{job.id}</div>
                      <div className="text-xs text-muted-foreground font-mono">Miner #{job.minerId} {job.createdAt && `\u2022 ${formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}`}</div>
                    </div>
                  </div>
                  <StatusBadge status={job.status} />
                </div>
              ))}
              {(!jobs || jobs.length === 0) && (
                <div className="text-center py-8 text-muted-foreground text-sm">No recent jobs</div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card data-testid="card-fleet-status">
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
            <CardTitle className="text-lg">Fleet Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm flex-wrap gap-2">
                <span className="text-muted-foreground">Online</span>
                <div className="flex items-center gap-2">
                  <div className="h-2 w-32 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 w-[85%]" />
                  </div>
                  <span className="font-mono text-emerald-500">85%</span>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm flex-wrap gap-2">
                <span className="text-muted-foreground">Overheated</span>
                <div className="flex items-center gap-2">
                  <div className="h-2 w-32 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full bg-amber-500 w-[5%]" />
                  </div>
                  <span className="font-mono text-amber-500">5%</span>
                </div>
              </div>
              <div className="flex items-center justify-between text-sm flex-wrap gap-2">
                <span className="text-muted-foreground">Offline</span>
                <div className="flex items-center gap-2">
                  <div className="h-2 w-32 bg-secondary rounded-full overflow-hidden">
                    <div className="h-full bg-zinc-600 w-[10%]" />
                  </div>
                  <span className="font-mono text-muted-foreground">10%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatsCard({ title, value, icon: Icon, trend, color }: any) {
  return (
    <Card data-testid={`card-stat-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4 flex-wrap gap-2">
          <div>
            <p className="text-sm text-muted-foreground font-medium">{title}</p>
            <h4 className="text-2xl font-bold mt-1 tracking-tight font-mono">{value}</h4>
          </div>
          <div className={`p-2 rounded-lg bg-secondary/50 ${color}`}>
            <Icon className="w-5 h-5" />
          </div>
        </div>
        <div className="flex items-center text-xs text-muted-foreground flex-wrap gap-1">
          <span className={`${color} font-medium`}>{trend}</span>
          <span>vs last 24h</span>
        </div>
      </CardContent>
    </Card>
  );
}
