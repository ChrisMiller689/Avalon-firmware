import { useState } from "react";
import { useMiners, useCreateMiner, useUpdateMiner, useDeleteMiner } from "@/hooks/use-miners";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { StatusBadge } from "@/components/StatusBadge";
import { Plus, MoreVertical, Search, Edit, Trash2 } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertMinerSchema, type InsertMiner } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

export default function Miners() {
  const { data: miners, isLoading } = useMiners();
  const [search, setSearch] = useState("");
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const filteredMiners = miners?.filter(m => 
    m.ipAddress.includes(search) || 
    m.model.toLowerCase().includes(search.toLowerCase()) ||
    m.status.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Miners</h2>
          <p className="text-muted-foreground">Manage your hardware inventory.</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="cyber-button bg-primary text-primary-foreground hover:bg-primary/90">
              <Plus className="w-4 h-4 mr-2" /> Add Miner
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle>Add New Miner</DialogTitle>
            </DialogHeader>
            <MinerForm onSuccess={() => setIsCreateOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex items-center gap-4 bg-card p-4 rounded-xl border border-border/50">
        <Search className="w-5 h-5 text-muted-foreground" />
        <Input 
          placeholder="Search by IP, Model or Status..." 
          className="cyber-input border-none bg-transparent focus:ring-0 px-0 text-base"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3].map(i => <div key={i} className="h-48 rounded-xl bg-secondary/50 animate-pulse" />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMiners?.map((miner) => (
            <MinerCard key={miner.id} miner={miner} />
          ))}
          {filteredMiners?.length === 0 && (
            <div className="col-span-full text-center py-12 text-muted-foreground">
              No miners found matching your search.
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function MinerCard({ miner }: { miner: any }) {
  const { toast } = useToast();
  const deleteMutation = useDeleteMiner();
  const [isEditOpen, setIsEditOpen] = useState(false);

  const handleDelete = async () => {
    if (confirm("Are you sure you want to remove this miner?")) {
      await deleteMutation.mutateAsync(miner.id);
      toast({ title: "Miner removed" });
    }
  };

  return (
    <div className="cyber-card rounded-xl p-6 transition-all hover:-translate-y-1 hover:shadow-lg hover:shadow-primary/5">
      <div className="flex justify-between items-start mb-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h3 className="font-mono font-bold text-lg">{miner.ipAddress}</h3>
            <StatusBadge status={miner.status} />
          </div>
          <p className="text-xs text-muted-foreground font-mono">{miner.macAddress || "No MAC Address"}</p>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="bg-popover border-border">
            <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
              <DialogTrigger asChild>
                <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                  <Edit className="w-4 h-4 mr-2" /> Edit Details
                </DropdownMenuItem>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Edit Miner</DialogTitle>
                </DialogHeader>
                <MinerForm miner={miner} onSuccess={() => setIsEditOpen(false)} />
              </DialogContent>
            </Dialog>
            <DropdownMenuItem className="text-red-500 focus:text-red-500" onClick={handleDelete}>
              <Trash2 className="w-4 h-4 mr-2" /> Remove
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border/50">
        <div>
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Hashrate</p>
          <p className="font-mono font-medium text-lg text-primary">{miner.currentHashrate} TH/s</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Temp</p>
          <p className="font-mono font-medium text-lg text-amber-500">{miner.currentTemp}°C</p>
        </div>
        <div className="col-span-2">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Model</p>
          <p className="font-medium text-sm">{miner.model}</p>
        </div>
      </div>
    </div>
  );
}

function MinerForm({ miner, onSuccess }: { miner?: any, onSuccess: () => void }) {
  const { toast } = useToast();
  const createMutation = useCreateMiner();
  const updateMutation = useUpdateMiner();

  const form = useForm<InsertMiner>({
    resolver: zodResolver(insertMinerSchema),
    defaultValues: miner || {
      ipAddress: "",
      macAddress: "",
      model: "Avalon A16",
      status: "offline",
      activeProfileId: null
    }
  });

  const onSubmit = async (data: InsertMiner) => {
    try {
      if (miner) {
        await updateMutation.mutateAsync({ id: miner.id, ...data });
        toast({ title: "Miner updated successfully" });
      } else {
        await createMutation.mutateAsync(data);
        toast({ title: "Miner added successfully" });
      }
      onSuccess();
    } catch (error) {
      toast({ variant: "destructive", title: "Operation failed", description: (error as Error).message });
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="ipAddress"
          render={({ field }) => (
            <FormItem>
              <FormLabel>IP Address</FormLabel>
              <FormControl>
                <Input placeholder="192.168.1.100" className="cyber-input" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="macAddress"
          render={({ field }) => (
            <FormItem>
              <FormLabel>MAC Address</FormLabel>
              <FormControl>
                <Input placeholder="00:11:22:33:44:55" className="cyber-input" {...field} value={field.value || ''} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="model"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Model</FormLabel>
              <FormControl>
                <Input placeholder="Avalon A16" className="cyber-input" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <Button type="submit" className="w-full cyber-button bg-primary text-primary-foreground hover:bg-primary/90" disabled={createMutation.isPending || updateMutation.isPending}>
          {miner ? "Save Changes" : "Add Miner"}
        </Button>
      </form>
    </Form>
  );
}
