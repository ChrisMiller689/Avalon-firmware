import { useState } from "react";
import { useProfiles } from "@/hooks/use-profiles";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileJson, FileText, Package, CheckCircle2, Cpu, Zap, Thermometer, Fan } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Profile } from "@shared/schema";

export default function Export() {
  const { data: profiles, isLoading } = useProfiles();
  const { toast } = useToast();
  const [selectedProfileId, setSelectedProfileId] = useState<number | null>(null);
  const [exportedIds, setExportedIds] = useState<Set<string>>(new Set());

  const selectedProfile = profiles?.find((p) => p.id === selectedProfileId);

  const handleExport = async (profile: Profile, format: "json" | "conf") => {
    try {
      const res = await fetch(`/api/profiles/${profile.id}/export?format=${format}`);
      if (!res.ok) throw new Error("Export failed");

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${profile.name.replace(/\s+/g, "_")}_config.${format}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setExportedIds((prev) => new Set(prev).add(`${profile.id}-${format}`));
      toast({
        title: "Config Exported",
        description: `${profile.name} exported as .${format} file.`,
      });
    } catch {
      toast({
        variant: "destructive",
        title: "Export Failed",
        description: "Could not generate config file.",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-primary/10 mb-4 border border-primary/20">
          <Package className="w-8 h-8 text-primary" />
        </div>
        <h2 className="text-3xl font-bold tracking-tight" data-testid="text-export-title">Export Firmware Configs</h2>
        <p className="text-muted-foreground mt-2 max-w-lg mx-auto">
          Download ready-to-deploy configuration files for your Avalon A16. Upload them via the miner's web interface to apply tuning parameters.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Select a Profile</h3>
          {(!profiles || profiles.length === 0) ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No profiles found. Create a profile first.</p>
            </Card>
          ) : (
            <div className="space-y-3">
              {profiles.map((profile) => (
                <Card
                  key={profile.id}
                  className={`p-4 cursor-pointer transition-all duration-200 ${
                    selectedProfileId === profile.id
                      ? "border-primary/50 bg-primary/5"
                      : "hover-elevate"
                  }`}
                  onClick={() => setSelectedProfileId(profile.id)}
                  data-testid={`card-profile-export-${profile.id}`}
                >
                  <div className="flex items-center justify-between gap-4 flex-wrap">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-3 h-3 rounded-full ${selectedProfileId === profile.id ? "bg-primary" : "bg-muted-foreground/30"}`} />
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-semibold truncate" data-testid={`text-profile-name-${profile.id}`}>{profile.name}</h4>
                          {profile.isAiOptimized && (
                            <Badge variant="secondary" className="text-xs">AI</Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground truncate">{profile.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground font-mono flex-wrap">
                      <span className="flex items-center gap-1"><Zap className="w-3 h-3" />{profile.targetHashrate}TH/s</span>
                      <span className="flex items-center gap-1"><Thermometer className="w-3 h-3" />{profile.targetPower}W</span>
                      <span className="flex items-center gap-1"><Cpu className="w-3 h-3" />{profile.mhzFrequency || 450}MHz</span>
                      <span className="flex items-center gap-1"><Fan className="w-3 h-3" />{profile.fanSpeed}%</span>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-4">
          <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Export Format</h3>
          <Card className="p-5 space-y-4">
            {selectedProfile ? (
              <>
                <div className="text-sm">
                  <span className="text-muted-foreground">Exporting:</span>
                  <span className="font-semibold ml-1" data-testid="text-selected-profile">{selectedProfile.name}</span>
                </div>

                <div className="space-y-3">
                  <Button
                    className="w-full justify-start gap-3"
                    variant={exportedIds.has(`${selectedProfile.id}-json`) ? "secondary" : "default"}
                    onClick={() => handleExport(selectedProfile, "json")}
                    data-testid="button-export-json"
                  >
                    {exportedIds.has(`${selectedProfile.id}-json`) ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <FileJson className="w-4 h-4" />
                    )}
                    <div className="text-left">
                      <div className="font-semibold">JSON Config</div>
                      <div className="text-xs opacity-70">Machine-readable, for automation</div>
                    </div>
                  </Button>

                  <Button
                    className="w-full justify-start gap-3"
                    variant={exportedIds.has(`${selectedProfile.id}-conf`) ? "secondary" : "outline"}
                    onClick={() => handleExport(selectedProfile, "conf")}
                    data-testid="button-export-conf"
                  >
                    {exportedIds.has(`${selectedProfile.id}-conf`) ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <FileText className="w-4 h-4" />
                    )}
                    <div className="text-left">
                      <div className="font-semibold">INI / Conf File</div>
                      <div className="text-xs opacity-70">For cgminer/bmminer web upload</div>
                    </div>
                  </Button>
                </div>

                <div className="bg-secondary/30 border border-border/50 rounded-lg p-3 mt-2">
                  <h5 className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wider">Config Summary</h5>
                  <div className="grid grid-cols-2 gap-y-2 gap-x-4 text-xs font-mono">
                    <span className="text-muted-foreground">Frequency</span>
                    <span>{selectedProfile.mhzFrequency || 450} MHz</span>
                    <span className="text-muted-foreground">Voltage</span>
                    <span>{(selectedProfile.voltageOffset || 0) > 0 ? "+" : ""}{selectedProfile.voltageOffset || 0}</span>
                    <span className="text-muted-foreground">Fan</span>
                    <span>{selectedProfile.fanSpeed}%</span>
                    <span className="text-muted-foreground">Target</span>
                    <span>{selectedProfile.targetHashrate} TH/s</span>
                    <span className="text-muted-foreground">Power</span>
                    <span>{selectedProfile.targetPower}W</span>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center py-8">
                <Download className="w-8 h-8 text-muted-foreground/30 mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">Select a profile to export</p>
              </div>
            )}
          </Card>

          <Card className="p-4">
            <h5 className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wider">How to Flash</h5>
            <ol className="text-xs text-muted-foreground space-y-2 list-decimal list-inside">
              <li>Download the config file above</li>
              <li>Open your miner's web interface (usually http://miner-ip)</li>
              <li>Navigate to Configuration or System tab</li>
              <li>Upload the config file and apply</li>
              <li>Miner will restart with new settings</li>
            </ol>
          </Card>
        </div>
      </div>
    </div>
  );
}
