import { useState } from "react";
import { useMiners } from "@/hooks/use-miners";
import { useProfiles } from "@/hooks/use-profiles";
import { useCreateBuildJob } from "@/hooks/use-builds";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Cpu, ArrowRight, CheckCircle2, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Build() {
  const { data: miners } = useMiners();
  const { data: profiles } = useProfiles();
  const createJob = useCreateBuildJob();
  const { toast } = useToast();

  const [selectedMinerId, setSelectedMinerId] = useState<string>("");
  const [selectedProfileId, setSelectedProfileId] = useState<string>("");

  const handleBuild = async () => {
    if (!selectedMinerId || !selectedProfileId) return;
    
    try {
      await createJob.mutateAsync({
        minerId: parseInt(selectedMinerId),
        profileId: parseInt(selectedProfileId),
        status: "pending"
      });
      toast({ 
        title: "Build Job Started", 
        description: "Firmware is being compiled and will be flashed shortly." 
      });
    } catch (err) {
      toast({ 
        variant: "destructive", 
        title: "Build Failed", 
        description: (err as Error).message 
      });
    }
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="text-center mb-12">
        <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-primary/10 mb-4 border border-primary/20">
          <Cpu className="w-8 h-8 text-primary" />
        </div>
        <h2 className="text-3xl font-bold tracking-tight">Build & Flash Firmware</h2>
        <p className="text-muted-foreground mt-2">Generate custom tuning packages and deploy to miners.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
        {/* Step 1: Miner */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-6 h-6 rounded-full bg-secondary flex items-center justify-center text-xs font-bold border border-border">1</div>
            <h3 className="font-semibold">Select Target</h3>
          </div>
          <Card className="p-4 bg-card border-border hover:border-primary/50 transition-colors">
            <Select onValueChange={setSelectedMinerId} value={selectedMinerId}>
              <SelectTrigger className="w-full bg-secondary/50 border-border">
                <SelectValue placeholder="Select Miner" />
              </SelectTrigger>
              <SelectContent>
                {miners?.map(m => (
                  <SelectItem key={m.id} value={m.id.toString()}>
                    {m.ipAddress} ({m.model})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-2 px-1">
              Choose the hardware target for this build.
            </p>
          </Card>
        </div>

        <div className="hidden md:flex justify-center text-muted-foreground">
          <ArrowRight className="w-6 h-6 opacity-20" />
        </div>

        {/* Step 2: Profile */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-6 h-6 rounded-full bg-secondary flex items-center justify-center text-xs font-bold border border-border">2</div>
            <h3 className="font-semibold">Select Profile</h3>
          </div>
          <Card className="p-4 bg-card border-border hover:border-primary/50 transition-colors">
            <Select onValueChange={setSelectedProfileId} value={selectedProfileId}>
              <SelectTrigger className="w-full bg-secondary/50 border-border">
                <SelectValue placeholder="Select Profile" />
              </SelectTrigger>
              <SelectContent>
                {profiles?.map(p => (
                  <SelectItem key={p.id} value={p.id.toString()}>
                    {p.name} ({p.targetHashrate}T)
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-2 px-1">
              Configuration to compile into firmware.
            </p>
          </Card>
        </div>
      </div>

      <div className="flex justify-center pt-8">
        <Button 
          size="lg" 
          className="w-full md:w-auto px-12 h-14 text-lg font-mono cyber-button bg-primary text-primary-foreground shadow-lg shadow-primary/20 hover:shadow-primary/40 hover:-translate-y-0.5"
          disabled={!selectedMinerId || !selectedProfileId || createJob.isPending}
          onClick={handleBuild}
        >
          {createJob.isPending ? "Compiling..." : "Build & Flash Firmware"}
        </Button>
      </div>

      <div className="bg-secondary/20 border border-border/50 rounded-xl p-6 mt-12">
        <h4 className="text-sm font-semibold mb-4 uppercase tracking-wider text-muted-foreground">Safety Checks</h4>
        <div className="grid gap-3">
          <SafetyCheck label="Hardware compatibility verified" passed={true} />
          <SafetyCheck label="Profile parameters within safe limits" passed={!!selectedProfileId} />
          <SafetyCheck label="Network connection stable" passed={true} />
        </div>
      </div>
    </div>
  );
}

function SafetyCheck({ label, passed }: { label: string, passed: boolean }) {
  return (
    <div className="flex items-center gap-3 text-sm">
      {passed ? (
        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
      ) : (
        <AlertCircle className="w-4 h-4 text-muted-foreground" />
      )}
      <span className={passed ? "text-foreground" : "text-muted-foreground"}>{label}</span>
    </div>
  );
}
