#!/bin/bash
OUTPUT="avalon-hut8-source-review.txt"
echo "============================================================" > "$OUTPUT"
echo "  AVALON BY HUT8 - FIRMWARE DESIGN & CONFIG TOOL" >> "$OUTPUT"
echo "  Complete Source Code for Independent Review" >> "$OUTPUT"
echo "  Generated: $(date -u '+%Y-%m-%d %H:%M UTC')" >> "$OUTPUT"
echo "============================================================" >> "$OUTPUT"
echo "" >> "$OUTPUT"

# Table of contents
echo "TABLE OF CONTENTS" >> "$OUTPUT"
echo "============================================================" >> "$OUTPUT"
echo "" >> "$OUTPUT"

SECTIONS=(
  "1. PROJECT CONFIGURATION"
  "   - package.json"
  "   - tsconfig.json"
  "   - vite.config.ts"
  "   - tailwind.config.ts"
  "   - drizzle.config.ts"
  "   - postcss.config.js"
  "   - components.json"
  ""
  "2. SHARED (Frontend + Backend)"
  "   - shared/schema.ts (Database schema & types)"
  "   - shared/routes.ts (API contract)"
  ""
  "3. SERVER (Backend)"
  "   - server/index.ts (Entry point)"
  "   - server/routes.ts (API routes)"
  "   - server/storage.ts (Database operations)"
  "   - server/db.ts (Database connection)"
  "   - server/vite.ts (Dev server setup)"
  "   - server/static.ts (Static file serving)"
  ""
  "4. CLIENT (Frontend)"
  "   - client/index.html"
  "   - client/src/main.tsx"
  "   - client/src/App.tsx"
  "   - client/src/index.css"
  "   - client/src/lib/ (Utilities)"
  "   - client/src/hooks/ (React hooks)"
  "   - client/src/pages/ (Page components)"
  "   - client/src/components/ (UI components)"
  ""
  "5. PWA"
  "   - client/public/manifest.json"
  "   - client/public/sw.js"
)

for line in "${SECTIONS[@]}"; do
  echo "$line" >> "$OUTPUT"
done
echo "" >> "$OUTPUT"
echo "============================================================" >> "$OUTPUT"
echo "" >> "$OUTPUT"

append_file() {
  local filepath="$1"
  local label="$2"
  if [ -f "$filepath" ]; then
    echo "" >> "$OUTPUT"
    echo "============================================================" >> "$OUTPUT"
    echo "FILE: $label" >> "$OUTPUT"
    echo "PATH: $filepath" >> "$OUTPUT"
    echo "============================================================" >> "$OUTPUT"
    echo "" >> "$OUTPUT"
    cat "$filepath" >> "$OUTPUT"
    echo "" >> "$OUTPUT"
  fi
}

# 1. Project config
append_file "package.json" "package.json"
append_file "tsconfig.json" "tsconfig.json"
append_file "vite.config.ts" "vite.config.ts"
append_file "tailwind.config.ts" "tailwind.config.ts"
append_file "drizzle.config.ts" "drizzle.config.ts"
append_file "postcss.config.js" "postcss.config.js"
append_file "components.json" "components.json"

# 2. Shared
append_file "shared/schema.ts" "shared/schema.ts"
append_file "shared/routes.ts" "shared/routes.ts"
if [ -f "shared/models/chat.ts" ]; then
  append_file "shared/models/chat.ts" "shared/models/chat.ts"
fi

# 3. Server
append_file "server/index.ts" "server/index.ts"
append_file "server/routes.ts" "server/routes.ts"
append_file "server/storage.ts" "server/storage.ts"
append_file "server/db.ts" "server/db.ts"
append_file "server/vite.ts" "server/vite.ts"
append_file "server/static.ts" "server/static.ts"

# 4. Client
append_file "client/index.html" "client/index.html"
append_file "client/src/main.tsx" "client/src/main.tsx"
append_file "client/src/App.tsx" "client/src/App.tsx"
append_file "client/src/index.css" "client/src/index.css"

# Lib
for f in client/src/lib/*.ts; do
  [ -f "$f" ] && append_file "$f" "$f"
done

# Hooks
for f in client/src/hooks/*.ts client/src/hooks/*.tsx; do
  [ -f "$f" ] && append_file "$f" "$f"
done

# Pages
for f in client/src/pages/*.tsx; do
  [ -f "$f" ] && append_file "$f" "$f"
done

# UI Components
for f in client/src/components/ui/*.tsx; do
  [ -f "$f" ] && append_file "$f" "$f"
done

# App-level components
for f in client/src/components/*.tsx; do
  [ -f "$f" ] && append_file "$f" "$f"
done

# 5. PWA
append_file "client/public/manifest.json" "client/public/manifest.json"
append_file "client/public/sw.js" "client/public/sw.js"

# replit.md (project docs)
append_file "replit.md" "replit.md (Project Documentation)"

# Summary
TOTAL_LINES=$(wc -l < "$OUTPUT")
echo "" >> "$OUTPUT"
echo "============================================================" >> "$OUTPUT"
echo "END OF SOURCE CODE REVIEW BUNDLE" >> "$OUTPUT"
echo "Total lines: $TOTAL_LINES" >> "$OUTPUT"
echo "============================================================" >> "$OUTPUT"

echo "Generated: $OUTPUT ($TOTAL_LINES lines)"
