import { z } from 'zod';
import { 
  insertMinerSchema, 
  insertProfileSchema, 
  insertBuildJobSchema,
  insertSiteSchema,
  insertAreaSchema,
  insertRackSchema,
  insertShelfSchema,
  insertMinerModelSchema,
  miners,
  profiles,
  buildJobs,
  sites,
  areas,
  racks,
  shelves,
  minerModels,
} from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  minerModels: {
    list: {
      method: 'GET' as const,
      path: '/api/miner-models' as const,
      responses: {
        200: z.array(z.custom<typeof minerModels.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/miner-models/:id' as const,
      responses: {
        200: z.custom<typeof minerModels.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  miners: {
    list: {
      method: 'GET' as const,
      path: '/api/miners' as const,
      responses: {
        200: z.array(z.custom<typeof miners.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/miners/:id' as const,
      responses: {
        200: z.custom<typeof miners.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/miners' as const,
      input: insertMinerSchema,
      responses: {
        201: z.custom<typeof miners.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/miners/:id' as const,
      input: insertMinerSchema.partial(),
      responses: {
        200: z.custom<typeof miners.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/miners/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  profiles: {
    list: {
      method: 'GET' as const,
      path: '/api/profiles' as const,
      responses: {
        200: z.array(z.custom<typeof profiles.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/profiles/:id' as const,
      responses: {
        200: z.custom<typeof profiles.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/profiles' as const,
      input: insertProfileSchema,
      responses: {
        201: z.custom<typeof profiles.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/profiles/:id' as const,
      input: insertProfileSchema.partial(),
      responses: {
        200: z.custom<typeof profiles.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/profiles/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      },
    },
  },
  ai: {
    optimize: {
      method: 'POST' as const,
      path: '/api/ai/optimize' as const,
      input: z.object({
        goal: z.enum(["efficiency", "performance", "balanced"]),
        constraints: z.object({
          maxPower: z.number().optional(),
          minHashrate: z.number().optional(),
          maxTemp: z.number().optional(),
        }).optional(),
      }),
      responses: {
        200: z.object({
          recommendedProfile: insertProfileSchema.partial(),
          reasoning: z.string(),
        }),
      },
    },
  },
  builds: {
    create: {
      method: 'POST' as const,
      path: '/api/builds' as const,
      input: insertBuildJobSchema,
      responses: {
        201: z.custom<typeof buildJobs.$inferSelect>(),
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/builds' as const,
      responses: {
        200: z.array(z.custom<typeof buildJobs.$inferSelect>()),
      },
    },
  },
  sites: {
    list: {
      method: 'GET' as const,
      path: '/api/sites' as const,
    },
    create: {
      method: 'POST' as const,
      path: '/api/sites' as const,
      input: insertSiteSchema,
    },
    update: {
      method: 'PUT' as const,
      path: '/api/sites/:id' as const,
      input: insertSiteSchema.partial(),
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/sites/:id' as const,
    },
  },
  areas: {
    list: {
      method: 'GET' as const,
      path: '/api/sites/:siteId/areas' as const,
    },
    create: {
      method: 'POST' as const,
      path: '/api/areas' as const,
      input: insertAreaSchema,
    },
    update: {
      method: 'PUT' as const,
      path: '/api/areas/:id' as const,
      input: insertAreaSchema.partial(),
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/areas/:id' as const,
    },
  },
  racks: {
    list: {
      method: 'GET' as const,
      path: '/api/areas/:areaId/racks' as const,
    },
    create: {
      method: 'POST' as const,
      path: '/api/racks' as const,
      input: insertRackSchema,
    },
    update: {
      method: 'PUT' as const,
      path: '/api/racks/:id' as const,
      input: insertRackSchema.partial(),
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/racks/:id' as const,
    },
  },
  shelves: {
    list: {
      method: 'GET' as const,
      path: '/api/racks/:rackId/shelves' as const,
    },
    create: {
      method: 'POST' as const,
      path: '/api/shelves' as const,
      input: insertShelfSchema,
    },
    update: {
      method: 'PUT' as const,
      path: '/api/shelves/:id' as const,
      input: insertShelfSchema.partial(),
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/shelves/:id' as const,
    },
  },
  hierarchy: {
    tree: {
      method: 'GET' as const,
      path: '/api/hierarchy/tree' as const,
    },
    minersByShelf: {
      method: 'GET' as const,
      path: '/api/shelves/:shelfId/miners' as const,
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
