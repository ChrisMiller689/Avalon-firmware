import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

// === TABLE DEFINITIONS ===

export const minerModels = pgTable("miner_models", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  series: text("series").notNull(),
  coolingType: text("cooling_type").notNull(),
  defaultHashrate: integer("default_hashrate").notNull(),
  defaultPower: integer("default_power").notNull(),
  efficiency: text("efficiency").notNull(),
  minFrequency: integer("min_frequency").notNull(),
  maxFrequency: integer("max_frequency").notNull(),
  defaultFrequency: integer("default_frequency").notNull(),
  minPower: integer("min_power").notNull(),
  maxPower: integer("max_power").notNull(),
  minThermal: integer("min_thermal").notNull(),
  maxThermal: integer("max_thermal").notNull(),
  defaultThermal: integer("default_thermal").notNull(),
  minVoltageOffset: integer("min_voltage_offset").notNull(),
  maxVoltageOffset: integer("max_voltage_offset").notNull(),
  hasFans: boolean("has_fans").notNull().default(true),
});

export const sites = pgTable("sites", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location"),
});

export const areas = pgTable("areas", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  siteId: integer("site_id").notNull(),
});

export const racks = pgTable("racks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  areaId: integer("area_id").notNull(),
});

export const shelves = pgTable("shelves", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rackId: integer("rack_id").notNull(),
});

export const miners = pgTable("miners", {
  id: serial("id").primaryKey(),
  ipAddress: text("ip_address").notNull(),
  macAddress: text("mac_address").unique(),
  model: text("model").notNull().default("Avalon A16"),
  status: text("status").notNull().default("offline"),
  currentHashrate: integer("current_hashrate").default(0),
  currentTemp: integer("current_temp").default(0),
  activeProfileId: integer("active_profile_id"),
  shelfId: integer("shelf_id"),
  lastSeen: timestamp("last_seen").defaultNow(),
});

export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  modelId: integer("model_id"),
  targetHashrate: integer("target_hashrate"), // TH/s
  targetPower: integer("target_power"), // Watts (stored as watts, displayed as kW)
  voltageOffset: integer("voltage_offset").default(0), // -2 to +1 usually
  fanSpeed: integer("fan_speed").default(100), // 0-100%
  mhzFrequency: integer("mhz_frequency").default(250), // MHz slider 200-300
  thermalThreshold: integer("thermal_threshold").default(85), // 10-100 Celsius
  powerCapEnabled: boolean("power_cap_enabled").default(false),
  powerCapLimit: integer("power_cap_limit").default(3500), // Watts cap limit
  autoTuneMode: text("auto_tune_mode").default("none"), // none, power, hashrate, efficiency, temperature
  autoTuneTarget: integer("auto_tune_target"), // target value for the selected mode
  isAiOptimized: boolean("is_ai_optimized").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const buildJobs = pgTable("build_jobs", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id").notNull(),
  minerId: integer("miner_id"),
  status: text("status").notNull().default("pending"), // pending, building, flashing, complete, failed
  logOutput: text("log_output"),
  createdAt: timestamp("created_at").defaultNow(),
});

// === RELATIONS ===

// === BASE SCHEMAS ===
export const insertMinerModelSchema = createInsertSchema(minerModels).omit({ id: true });
export const insertSiteSchema = createInsertSchema(sites).omit({ id: true });
export const insertAreaSchema = createInsertSchema(areas).omit({ id: true });
export const insertRackSchema = createInsertSchema(racks).omit({ id: true });
export const insertShelfSchema = createInsertSchema(shelves).omit({ id: true });
export const insertMinerSchema = createInsertSchema(miners).omit({ id: true, lastSeen: true, currentHashrate: true, currentTemp: true });
export const insertProfileSchema = createInsertSchema(profiles).omit({ id: true, createdAt: true, updatedAt: true });
export const insertBuildJobSchema = createInsertSchema(buildJobs).omit({ id: true, createdAt: true, logOutput: true });

// === EXPLICIT API CONTRACT TYPES ===

// Miner Model types
export type MinerModel = typeof minerModels.$inferSelect;
export type InsertMinerModel = z.infer<typeof insertMinerModelSchema>;

// Hierarchy types
export type Site = typeof sites.$inferSelect;
export type InsertSite = z.infer<typeof insertSiteSchema>;
export type Area = typeof areas.$inferSelect;
export type InsertArea = z.infer<typeof insertAreaSchema>;
export type Rack = typeof racks.$inferSelect;
export type InsertRack = z.infer<typeof insertRackSchema>;
export type Shelf = typeof shelves.$inferSelect;
export type InsertShelf = z.infer<typeof insertShelfSchema>;

// Base types
export type Miner = typeof miners.$inferSelect;
export type InsertMiner = z.infer<typeof insertMinerSchema>;

export type Profile = typeof profiles.$inferSelect;
export type InsertProfile = z.infer<typeof insertProfileSchema>;

export type BuildJob = typeof buildJobs.$inferSelect;
export type InsertBuildJob = z.infer<typeof insertBuildJobSchema>;

// Request types
export type CreateMinerRequest = InsertMiner;
export type UpdateMinerRequest = Partial<InsertMiner>;

export type CreateProfileRequest = InsertProfile;
export type UpdateProfileRequest = Partial<InsertProfile>;

export type CreateBuildJobRequest = InsertBuildJob;

// AI Optimization
export type AiOptimizeRequest = {
  goal: "efficiency" | "performance" | "balanced";
  constraints?: {
    maxPower?: number;
    minHashrate?: number;
    maxTemp?: number;
  };
};

export type AiOptimizeResponse = {
  recommendedProfile: Partial<InsertProfile>;
  reasoning: string;
};

// Response types
export type MinerResponse = Miner;
export type ProfileResponse = Profile;
export type BuildJobResponse = BuildJob;

export type MinersListResponse = Miner[];
export type ProfilesListResponse = Profile[];
