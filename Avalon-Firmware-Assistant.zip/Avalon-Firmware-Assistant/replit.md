# Avalon by Hut8 - Firmware Design & Config Tool

## Overview
A web-based PWA (Progressive Web App) for designing, optimizing, and exporting Avalon ASIC miner firmware configurations. Supports all current Avalon models (air, hydro, immersion, home). Works offline and can be installed on any device like a desktop application.

## Recent Changes
- 2026-02-19: Multi-model support: model selector in profiles with dynamic parameter ranges based on selected miner model
- 2026-02-19: Added minerModels table with 16 Avalon models (A16, A15, hydro, immersion, home series) with per-model specs
- 2026-02-19: Auto-tune system now adapts to selected model's frequency/power/thermal ranges
- 2026-02-19: Fan speed control hidden for immersion/hydro models (no fans)
- 2026-02-19: Fleet Deploy redesigned with site hierarchy (Site → Area/Container → Rack → Shelf) with select-all at each level, supports 100k+ miners per site
- 2026-02-19: Added hierarchy tables (sites, areas, racks, shelves) with miners assigned to shelves
- 2026-02-19: Added Auto-Tune system: lock one parameter (power/hashrate/efficiency/temperature) and auto-calculate all other settings
- 2026-02-19: Added Firmware SDK page with Canaan repos, cgminer config builder, API reference, and build pipeline
- 2026-02-19: Added PWA support (manifest, service worker, offline capability)
- 2026-02-19: Added firmware config export feature (JSON and .conf formats)
- 2026-02-19: Added Export Config page with download functionality
- 2026-02-19: Added MHz chip frequency control with power/heat curve chart
- 2026-02-19: AI optimization includes frequency recommendations

## Project Architecture
- **Frontend**: React + Vite + TailwindCSS + shadcn/ui
- **Backend**: Express.js with typed API routes
- **Database**: PostgreSQL (Drizzle ORM)
- **AI**: OpenAI integration for profile optimization
- **Routing**: wouter (frontend), shared/routes.ts (API contract)

### Key Pages
- `/` - Dashboard with fleet overview and power/heat chart
- `/miners` - Miner management
- `/profiles` - Tuning profile editor with MHz slider and auto-tune
- `/deploy` - Fleet Deploy: hierarchical site→area→rack→shelf selection with select-all, push configs to miners
- `/build` - Build & flash firmware jobs
- `/export` - Export firmware config files (JSON / .conf)
- `/sdk` - Firmware SDK with resources, config builder, API reference, and build pipeline

### Key Files
- `shared/schema.ts` - Database schema and types
- `shared/routes.ts` - API contract definitions
- `server/routes.ts` - Backend routes + firmware export endpoint
- `server/storage.ts` - Database CRUD operations
- `client/src/pages/` - Page components
- `client/src/hooks/` - React Query hooks
- `client/public/manifest.json` - PWA manifest
- `client/public/sw.js` - Service worker for offline support

### API Endpoints
- `GET/POST /api/miners` - Miner CRUD
- `GET/POST /api/profiles` - Profile CRUD
- `GET /api/profiles/:id/export?format=json|conf` - Firmware config export
- `POST /api/ai/optimize` - AI-powered profile optimization
- `GET/POST /api/builds` - Build job management
- `GET /api/miner-models` - List all miner models
- `GET /api/miner-models/:id` - Get single miner model
- `GET/POST /api/sites` - Site CRUD
- `GET /api/sites/:siteId/areas` - Areas by site
- `POST /api/areas` - Area CRUD
- `GET /api/areas/:areaId/racks` - Racks by area
- `POST /api/racks` - Rack CRUD
- `GET /api/racks/:rackId/shelves` - Shelves by rack
- `POST /api/shelves` - Shelf CRUD
- `GET /api/hierarchy/tree` - Full hierarchy tree with miner counts
- `GET /api/shelves/:shelfId/miners` - Miners by shelf
- `POST /api/fleet/deploy` - Deploy config to miners (accepts shelfIds/rackIds/areaIds/siteIds)

## User Preferences
- Avalon A16 ASIC miner focus
- Cyberpunk/industrial dark UI theme
- MHz frequency range: 200-400 MHz
- Thermal threshold range: 10-100°C
- Power range: 3.00-4.00 kW (stored as watts 3000-4000)
- Power cap feature: checkbox locks power slider to not exceed set limit
